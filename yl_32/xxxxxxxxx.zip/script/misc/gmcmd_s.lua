
if not MODULE_GAMESERVER then
	return
end
--zzf
Lang.misc.str13 = {"��װ","","","","",""}
Lang.misc.str14 = {"��װ","","","","",""}
Lang.misc.str15 = {"��װ","","","","",""}
Lang.misc.str16 = {"��װ","","","","",""}
Lang.misc.str17 = {"����","","","","",""}
Lang.misc.str18 = {"���ִ� - ��1","","","","",""}
Lang.misc.str19 = {"���ִ� - ��2","","","","",""}
Lang.misc.str20 = {"����M4","","","","",""}
Lang.misc.str21 = {"��ڤ","","","","",""}
Lang.misc.str22 = {"ɭ�ޣ�δ���ţ�","","","","",""}
Lang.misc.str23 = {"���ף�δ���ţ�","","","","",""}
Lang.misc.str24 = {"Ұ��","","","","",""}
Lang.misc.str25 = {"�ٻ���M4","","","","",""}
Lang.misc.str26 = {"��ʯ��","","","","",""}
Lang.misc.str27 = {"��������M4","","","","",""}
Lang.misc.str28 = {"�ٻ�կAM4","","","","",""}
Lang.misc.str29 = {"����Ĵ�","","","","",""}
Lang.misc.str30 = {"������","","","","",""}
Lang.misc.str31 = {"�彣ɽׯM4","","","","",""}
Lang.misc.str32 = {"����M4","","","","",""}
Lang.misc.str33 = {"�����M4","","","","",""}
Lang.misc.str34 = {"�޼�����M4","","","","",""}
Lang.misc.str35 = {"��ɽ�ȵ�M4","","","","",""}
Lang.misc.str36 = {"����","","","","",""}
Lang.misc.str37 = {"������M4","","","","",""}
Lang.misc.str38 = {"�ٻ��ܾ�M4","","","","",""}
Lang.misc.str39 = {"������M4","","","","",""}
Lang.misc.str40 = {"������M4","","","","",""}
Lang.misc.str41 = {"����կ","","","","",""}
Lang.misc.str42 = {"�ؿ�","","","","",""}
Lang.misc.str43 = {"�����޴���ң�","","","","",""}
Lang.misc.str44 = {"��ȡÿ�ո���","","","","",""}
Lang.misc.str45 = {"��������pk��","","","","",""}
Lang.misc.str46 = {"��ȡս��ҩƷ","","","","",""}
Lang.misc.str47 = {"�淨","","","","",""}
Lang.misc.str48 = {"GMָ�","","","","",""}
Lang.misc.str49 = {"��ѡ��Ҫ��������","","","","",""}
Lang.misc.str50 = {"���ͣ��ɿ����������ؿ���","","","","",""}
Lang.misc.str51 = {"��ȡ��������","","","","",""}
Lang.misc.str52 = {"���Ӿ���","","","","",""}
Lang.misc.str53 = {"��ȡ��������","","","","",""}
Lang.misc.str54 = {"���õȼ�","","","","",""}
Lang.misc.str55 = {"��ձ���","","","","",""}
Lang.misc.str56 = {"��ճ��ﱳ��","","","","",""}
Lang.misc.str57 = {"��һҳ","","","","",""}
Lang.misc.str58 = {"������gmָ���ֻ��gm���ð����국","","","","",""}
Lang.misc.str59 = {"���ﵺ","","","","",""}
Lang.misc.str60 = {"�˳���ǰ����","","","","",""}
Lang.misc.str61 = {"��һҳ","","","","",""}
Lang.misc.str62 = {"ѡ������淨��ָ�","","","","",""}
Lang.misc.str63 = {"������ﵺ","","","","",""}
Lang.misc.str64 = {"ˢ�³��ﵺ����","","","","",""}
Lang.misc.str65 = {"��ʼ������ս��","","","","",""}
Lang.misc.str66 = {"��ȡ�ʺ�װ��","","","","",""}
Lang.misc.str67 = {"��ȡ����","","","","",""}
Lang.misc.str68 = {"��ȡ��װ","","","","",""}
Lang.misc.str69 = {"��ȡ����","","","","",""}
Lang.misc.str70 = {"��ȡ����","","","","",""}
Lang.misc.str71 = {"ѡ����Ҫ��ȡ��װ������","","","","",""}
Lang.misc.str72 = {"����","","","","",""}
Lang.misc.str73 = {"��ѡ����Ҫ���͵ĵ���","","","","",""}
Lang.misc.str74 = {"�ؿ�","","","","",""}
Lang.misc.str75 = {"��","","","","",""}
Lang.misc.str76 = {"�е�(�ݲ�����)","","","","",""}
Lang.misc.str77 = {"����(�ݲ�����)","","","","",""}
Lang.misc.str78 = {"��һҳ","","","","",""}
Lang.misc.str79 = {"��","","","","",""}
Lang.misc.str80 = {"��","","","","",""}
Lang.misc.str81 = {"�Ƿ���Ҫ��������","","","","",""}
Lang.misc.str82 = {"�������","","","","",""}
Lang.misc.str83 = {"���Ѷ���δ����","","","","",""}
Lang.misc.str84 = {"��ȡ��С��","","","","",""}
Lang.misc.str85 = {"��ȡ˧С��","","","","",""}
Lang.misc.str86 = {"��ȡ��С��","","","","",""}
Lang.misc.str87 = {"��ȡ��С��","","","","",""}
Lang.misc.str88 = {"��һҳ","","","","",""}
Lang.misc.str89 = {"����","","","","",""}
Lang.misc.str90 = {"��ѡ��Ҫ��ȡ�ĳ�������","","","","",""}
Lang.misc.str91 = {"��ȡ�з","","","","",""}
Lang.misc.str92 = {"��ȡ����","","","","",""}
Lang.misc.str93 = {"��ȡʨ��","","","","",""}
Lang.misc.str94 = {"��ȡС��","","","","",""}
Lang.misc.str95 = {"��һҳ","","","","",""}
Lang.misc.str96 = {"��ȡ�Ը�һ����","","","","",""}
Lang.misc.str97 = {"��ȡ�Ը������","","","","",""}
Lang.misc.str98 = {"��ȡ�Ը�������","","","","",""}
Lang.misc.str99 = {"��ȡ�Ը��ĳ���","","","","",""}
Lang.misc.str110 = {"��ȡ�Ը������","","","","",""}
Lang.misc.str111 = {"��ȡ�Ը�������","","","","",""}
Lang.misc.str112 = {"��ȡ�Ը��߳���","","","","",""}
Lang.misc.str113 = {"��ѡ��Ҫ��ȡ�ĳ����Ը�","","","","",""}
Lang.misc.str114 = {"����������Ѿ����ˣ��뿪����������ȡ������","","","","",""}
Lang.misc.str115 = {"�����˳���: ","","","","",""}
Lang.misc.str116 = {"ʥ����װ","","","","",""}
Lang.misc.str117 = {"��è��װ","","","","",""}
Lang.misc.str118 = {"������װ��δ���ţ�","","","","",""}
Lang.misc.str119 = {"�п�����װ��δ���ţ�","","","","",""}
Lang.misc.str120 = {"������װ��δ���ţ�","","","","",""}
Lang.misc.str121 = {"��ѡ��Ҫ��ȡ����װ","","","","",""}
Lang.misc.str122 = {"�̽�","","","","",""}
Lang.misc.str123 = {"��","","","","",""}
Lang.misc.str124 = {"��","","","","",""}
Lang.misc.str125 = {"��","","","","",""}
Lang.misc.str126 = {"����","","","","",""}
Lang.misc.str127 = {"˫��","","","","",""}
Lang.misc.str128 = {"����","","","","",""}
Lang.misc.str129 = {"˫ذ","","","","",""}
Lang.misc.str130 = {"��װ","","","","",""}
Lang.misc.str131 = {"��װ","","","","",""}
Lang.misc.str132 = {"��װ","","","","",""}
Lang.misc.str133 = {"��װ","","","","",""}
Lang.misc.str134 = {"ȫ��","","","","",""}
Lang.misc.str135 = {"��","","","","",""}
Lang.misc.str136 = {"ѡ������Ʒ��","","","","",""}
Lang.misc.str137 = {"û�к��ʵ�װ��","","","","",""}
Lang.misc.str138 = {"����","","","","",""}
Lang.misc.str139 = {"����","","","","",""}
Lang.misc.str140 = {"����","","","","",""}
Lang.misc.str141 = {"Ь��","","","","",""}
Lang.misc.str142 = {"����","","","","",""}
Lang.misc.str143 = {"��ָ","","","","",""}
Lang.misc.str144 = {"����","","","","",""}
Lang.misc.str145 = {"����","","","","",""}
Lang.misc.str146 = {"ѡ����Ҫ�ķ�������","","","","",""}
Lang.misc.str147 = {"ѡ�����Ʒ�ʣ�������Ҫ������ѡȫ����","","","","",""}
Lang.misc.str148 = {"ѡ����ߵȼ�","","","","",""}
Lang.misc.str149 = {"������ԯ","","","","",""}
Lang.misc.str150 = {"��а����","","","","",""}
Lang.misc.str151 = {"������ڤ","","","","",""}
Lang.misc.str152 = {"��Ӱɭ��","","","","",""}
Lang.misc.str153 = {"ѡ����������","","","","",""}
Lang.misc.str154 = {"û�к��ʵ�װ��","","","","",""}
Lang.misc.str155 = {"����1000��ɫ����","","","","",""}
Lang.misc.str156 = {"����10000��ɫ����","","","","",""}
Lang.misc.str157 = {"����100000��ɫ����","","","","",""}
Lang.misc.str158 = {"��ѡ��Ҫ��õľ���","","","","",""}
Lang.misc.str159 = {"��ѡ��Ҫ��õ�������������","","","","",""}
Lang.misc.str160 = {"����ȼ���1 ~ 60��","","","","",""}
Lang.misc.str161 = {"����ĸ����Ѿ���ȡ���ˣ�����������","","","","",""}
Lang.misc.str162 = {"����ս����","","","","",""}
Lang.misc.str163 = {"��������","","","","",""}
Lang.misc.str164 = {"��ѡ��Ҫ�������Ӫ","","","","",""}
Lang.Idx = 1
GM.tbGM_CMD_HELPER = {}
local tbGmCmdHelper = GM.tbGM_CMD_HELPER

tbGmCmdHelper.tbEquipQuality = {
	[1] = Lang.misc.str13[Lang.Idx];
	[2] = Lang.misc.str14[Lang.Idx];
	[3] = Lang.misc.str15[Lang.Idx];
	[4] = Lang.misc.str16[Lang.Idx];
}

--����
tbGmCmdHelper.tbEQUIP_WEAPON = "/setting/item/equip/weapon.txt";

--����
tbGmCmdHelper.tbEQUIP_AMULET = "/setting/item/equip/amulet.txt";
tbGmCmdHelper.tbEQUIP_ARMOR = "/setting/item/equip/armor.txt";
tbGmCmdHelper.tbEQUIP_BELT = "/setting/item/equip/belt.txt";
tbGmCmdHelper.tbEQUIP_BRACERS = "/setting/item/equip/bracers.txt";
tbGmCmdHelper.tbEQUIP_FOOT = "/setting/item/equip/foot.txt";
tbGmCmdHelper.tbEQUIP_NECKLACE = "/setting/item/equip/necklace.txt";
tbGmCmdHelper.tbEQUIP_PENDANT = "/setting/item/equip/pendant.txt";
tbGmCmdHelper.tbEQUIP_RING = "/setting/item/equip/ring.txt";

--��װ
tbGmCmdHelper.tbEQUIP_HAT = "/setting/item/equip/hat.txt";
tbGmCmdHelper.tbEQUIP_SHOULDER = "/setting/item/equip/shoulder.txt";
tbGmCmdHelper.tbEQUIP_BACK = "/setting/item/equip/back.txt";
tbGmCmdHelper.tbEQUIP_BOTTOM = "/setting/item/equip/bottom.txt";

tbGmCmdHelper.tbMapData = 
{
	[Lang.misc.str17[Lang.Idx]] = 
		{
			{Lang.misc.str18[Lang.Idx], {3,6991,447,1048576}},
			{Lang.misc.str19[Lang.Idx], {3, 2657, 4916, 1048576}},
			{Lang.misc.str20[Lang.Idx], {100,1860,7139,1048576}},
			{Lang.misc.str21[Lang.Idx], {101,6460,1574,1050992}},
			{Lang.misc.str22[Lang.Idx], {101,6460,1574,1050992}},
			{Lang.misc.str23[Lang.Idx], {101,6460,1574,1050992}},
		},
	[Lang.misc.str24[Lang.Idx]] = 
		{
		  --{SceneName, {MapId,PosX,PosY,PosZ}},
			{Lang.misc.str25[Lang.Idx], {102,4178,1316,1063454}},
			{Lang.misc.str26[Lang.Idx], {105,1671,1634,1052154}},
			{Lang.misc.str27[Lang.Idx], {106,381,2410,1049620}},
			{Lang.misc.str28[Lang.Idx], {108,805,1251,1048576}},
			{Lang.misc.str29[Lang.Idx], {109,3423,846,1051136}},
			{Lang.misc.str30[Lang.Idx], {110,3473,791,1050204}},
			{Lang.misc.str31[Lang.Idx], {111,3732,1742,1055155}},
			{Lang.misc.str32[Lang.Idx]   , {112,385,1655,1048576}},
			{Lang.misc.str33[Lang.Idx], {113,795,2093,1048576}},
			{Lang.misc.str34[Lang.Idx], {115,1821,1007,1049082}},
			{Lang.misc.str35[Lang.Idx], {118,2232,741,1057786}},
		},
	[Lang.misc.str36[Lang.Idx]] =
		{
			{Lang.misc.str37[Lang.Idx], {301,3109,1659,1055093}},
			{Lang.misc.str38[Lang.Idx], {306,2522, 3801, 1054976}},
			{Lang.misc.str39[Lang.Idx], {316,4168, 1166, 1054704}},
			{Lang.misc.str40[Lang.Idx], {311,6581, 3779, 1055011}},
			{Lang.misc.str41[Lang.Idx], {321,7280, 6417, 1052666}},
		},
	[Lang.misc.str42[Lang.Idx]] =
		{
		},
}

tbGmCmdHelper.tbPKTelePos =
{
	[1] = {800,2723, 6287, 1048576},  --ս����
	[2] = {800,6287, 5682, 1048576},  --����
}

function GM:ShowAdvancedCommands()
	tbGmCmdHelper:ShowAdvancedCommands()
end

-- �����������ѡ�����
function GM:OperatePlayerByName(szTargetPlayerName)
	local pPlayer = KGameBase.GetPlayerByName(szTargetPlayerName)
	if pPlayer then
		tbGmCmdHelper:PlayerOps_Select(pPlayer.dwId, pPlayer.szName)
	else
		me.SysMsg(Lang.misc.str43[Lang.Idx]..szTargetPlayerName)
	end
end

-- ��ָ̬���
function tbGmCmdHelper:ShowAdvancedCommands()
	local tbOpt = 
	{
		{Lang.misc.str44[Lang.Idx],self.GetDailyAward,self},
		{Lang.misc.str45[Lang.Idx],self.GoToPK,self},
		{Lang.misc.str46[Lang.Idx],self.GetPKMedicine,self},
		{Lang.misc.str47[Lang.Idx], self.ShowPlayModes, self},
		{Lang.misc.str48[Lang.Idx],self.ShowAdvancedCommands2,self},
	}
	Dialog:SimpleSay(Lang.misc.str49[Lang.Idx], tbOpt)
end

function tbGmCmdHelper:ShowAdvancedCommands2()
	local tbOpt =
	{
		--{"�������ս��"},
		{Lang.misc.str50[Lang.Idx], self.TeleportSelect, self},
		--{"�����õ���", self.GetItem, self},
		{Lang.misc.str51[Lang.Idx], self.GetAllKindsEquip, self},
		{Lang.misc.str52[Lang.Idx], self.AddExp, self},
		{Lang.misc.str53[Lang.Idx], self.AddYLCoin, self},
		{Lang.misc.str54[Lang.Idx], self.PlayerLevelUp, self},
		{Lang.misc.str55[Lang.Idx], self.ClearBagRoom, self},
		{Lang.misc.str56[Lang.Idx], self.ClearPetBagRoom, self},
		{Lang.misc.str57[Lang.Idx], self.ShowAdvancedCommands, self},
		--{"", self.TestAccount, self, 1},
		{" "},
		--{"��ʾ�������", self.ShowAllPlayersOL, self},
		
		--{"������", function() me.SetVisible(1 - me.nVisible) end},
		--{"��������", function() me.SetMoveSpeed(60 - me.GetMoveSpeed()) end},
		--{"�����������", self.ListPlayers, self},
		--{"CallNpc", self.CallNpc_Select, self},
		--{"ϵͳָ��", self.SystemOps_Select, self},
		--{"��������", self.FinishAllFreshState, self, me.dwId},
	}
	Dialog:SimpleSay(Lang.misc.str58[Lang.Idx], tbOpt)
end	

-- �淨������ﵺ
function tbGmCmdHelper:ShowPlayModes()
	local tbOpt = 
	{
		{Lang.misc.str59[Lang.Idx], self.GMPetIsland, self},
		{Lang.misc.str60[Lang.Idx], Instance.LeaveMyInstance, Instance, me},
		{Lang.misc.str61[Lang.Idx], self.ShowAdvancedCommands, self},
	}
	Dialog:SimpleSay(Lang.misc.str62[Lang.Idx], tbOpt)
end

-- ���ﵺ���
function tbGmCmdHelper:GMPetIsland()
	local tbOpt = 
	{
		{Lang.misc.str63[Lang.Idx], PetIsland.c2s_EnterPetIsland, PetIsland, me};
		{Lang.misc.str64[Lang.Idx], PetIsland.c2s_RefreshPets, PetIsland, me},
		{Lang.misc.str65[Lang.Idx], PetIsland.c2s_StartFight, PetIsland, me},
		{Lang.misc.str61[Lang.Idx], self.ShowPlayModes, self},
	}
	Dialog:SimpleSay(Lang.misc.str62[Lang.Idx], tbOpt)
end

-- װ���������
function tbGmCmdHelper:GetAllKindsEquip()
	local tbOpt = 
	{
		{Lang.misc.str66[Lang.Idx], self.GetEquip, self},
		{Lang.misc.str67[Lang.Idx], self.GetPet, self},
		{Lang.misc.str68[Lang.Idx], self.GetFashion, self},
		{Lang.misc.str69[Lang.Idx], self.GetWeapon, self},
		{Lang.misc.str70[Lang.Idx], self.GetDefence, self},
	}
	Dialog:SimpleSay(Lang.misc.str71[Lang.Idx], tbOpt)
end

function tbGmCmdHelper:NavBack()
	self:ShowAdvancedCommands()
end

function tbGmCmdHelper:TeleportSelect()
	local tbOpt = {}
	
--	if me.GetPosition().dwSceneId == 800 then
--		Dialog:SimpleSay("�벻Ҫ��ս����ֱ�ӽ���gm���ͣ�������˶Ի������뿪ս��");
--	else
	for szArea, tbMap in pairs(self.tbMapData) do
		--if szArea == "Ұ��" then   --Ұ���ͼֱ�Ӵ���
			table.insert(tbOpt, {szArea, self.TeleportToMap, self, szArea, 1})
		--elseif szArea == "����" then   --������ͼѯ���Ƿ���
		--	table.insert(tbOpt, {szArea, self.TeleportToMap, self, szArea, 2, 1})
		--elseif szArea == "�ؿ�" then   --�ؿ���ͼѯ�ʽ����Ѷ�
			--table.insert(tbOpt, {szArea, self.TeleportToMap, self, szArea, 3})			
			--Dialog:SimpleSay("�ؿ��ݲ�����");
		--end
	end
	table.insert(tbOpt, {Lang.misc.str72[Lang.Idx], self.NavBack, self})
	Dialog:SimpleSay(Lang.misc.str73[Lang.Idx], tbOpt); 
end

function tbGmCmdHelper:TeleportToMap(szArea,nMapPos)
	local tbOpt = {}
	local nCount = 9;
	local tbMapData = self.tbMapData[szArea];
	local tbMapInfo = {};
	if szArea == Lang.misc.str74[Lang.Idx] then
		tbOpt = {
			{Lang.misc.str75[Lang.Idx],self.TeleportXMHJ,self,1},
			{Lang.misc.str76[Lang.Idx],self.TeleportXMHJ,self,2},
			{Lang.misc.str77[Lang.Idx],self.TeleportXMHJ,self,3},
		}
	else
		for i= nMapPos, #tbMapData do
			tbMapInfo = tbMapData[i];
			if nCount <= 1 then
				table.insert(tbOpt, {Lang.misc.str78[Lang.Idx], self.TeleportToMap, self, szArea , i});
				break;
			else
				if szArea == Lang.misc.str24[Lang.Idx] or szArea == Lang.misc.str17[Lang.Idx] then
					table.insert(tbOpt, {tbMapInfo[1], self.TeleportTo, self, tbMapInfo[2]});
					nCount = nCount - 1;
				elseif szArea == Lang.misc.str36[Lang.Idx] then
					table.insert(tbOpt, {tbMapInfo[1], self.TeleportInstance, self, tbMapInfo[2]});
					nCount = nCount - 1;	
				end			
			end
		end
	end
	table.insert(tbOpt, {Lang.misc.str72[Lang.Idx], self.NavBack, self, 0})
	Dialog:SimpleSay(Lang.misc.str73[Lang.Idx], tbOpt);
end

function tbGmCmdHelper:TeleportInstance(tbMapInfo)
	local tbOpt = {
		{Lang.misc.str79[Lang.Idx],self.StartInstance , self , tbMapInfo};
		{Lang.misc.str80[Lang.Idx],self.TeleportTo , self , tbMapInfo};
	}
	Dialog:SimpleSay(Lang.misc.str81[Lang.Idx], tbOpt);
end

function tbGmCmdHelper:StartInstance(tbMapInfo)
	if me.GetTeamId() and me.GetTeamId() > 0 then
		Instance:TryEnterInstance({me.dwId}, tbMapInfo[1]);
	else
		Dialog:SimpleSay(Lang.misc.str82[Lang.Idx]);
	end
end

function tbGmCmdHelper:TeleportXMHJ(nId)
	if me.GetTeamId() and me.GetTeamId() > 0 then
		if nId == 1 then
			XoyoGame:ApplyJoinGame(me, 1);
			XoyoGame:JoinNextGame(me);
			XoyoGame:StartGame_GS2();
		else
			Dialog:SimpleSay(Lang.misc.str83[Lang.Idx]);
		end
	else
		Dialog:SimpleSay(Lang.misc.str82[Lang.Idx]);
	end
end

function tbGmCmdHelper:TeleportTo(tbMapInfo)
	--KScene.LoadScene(tonumber(tbMapInfo[1]));
	me.TeleportTo(unpack(tbMapInfo));
end

function tbGmCmdHelper:GetEquip()
	local dwLevel = me.GetLevel();
	local nQualityMax = 4;
	local tbOpt = {}
	
	if dwLevel <= 9 then
		nQualityMax = 1;
	elseif dwLevel <= 29 and dwLevel >= 10 then
		nQualityMax = 2;
	elseif dwLevel <= 59 and dwLevel >= 30 then
		nQualityMax = 3;
	end
	local nFactionId = me.GetPrimaryFaction();
	local tbWeaponTable = {};
	local tbDefenceTable = {};
	local j = 1;
	
	local dwMinLevel = dwLevel - 10;
	if dwMinLevel < 0 then
		dwMinLevel = 1;
	end
	
	local nNeedLevel = ((dwMinLevel == 1) and dwMinLevel or (math.floor(dwLevel / 10) * 10));

	--��ȡ����	
	local tbWeaponData = Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_WEAPON) 

	for key,tbRow in pairs(tbWeaponData) do
		if tonumber(tbRow["ReqLevel"]) == nNeedLevel then
			if tonumber(tbRow["ReqProp1Type"]) == 3 and tonumber(tbRow["ReqProp1Value"]) == nFactionId then
				if tonumber(tbRow["Quality"]) == nQualityMax then
					tbWeaponTable[#tbWeaponTable + 1] = tbRow;
				end
			end
		end
	end
	
	-----------------------��ȡ����-------------------------
	--����
	local tbArmorData = Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_ARMOR) 

	for key,tbRow in pairs(tbArmorData) do
		if tonumber(tbRow["ReqLevel"]) == nNeedLevel then
			if tonumber(tbRow["ReqProp1Type"]) == 3 and tonumber(tbRow["ReqProp1Value"]) == nFactionId then
				if tonumber(tbRow["Quality"]) == nQualityMax then
					tbDefenceTable[#tbDefenceTable + 1] = tbRow;
				end
			end
		end
	end
	--����
	local tbBeltData = Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_BELT) 

	for key,tbRow in pairs(tbBeltData) do
		if tonumber(tbRow["ReqLevel"]) == nNeedLevel then
			if tonumber(tbRow["ReqProp1Type"]) == 3 and tonumber(tbRow["ReqProp1Value"]) == nFactionId then
				if tonumber(tbRow["Quality"]) == nQualityMax then
					tbDefenceTable[#tbDefenceTable + 1] = tbRow;
				end
			end
		end
	end
	--����
	local tbBracersData = Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_BRACERS) 

	for key,tbRow in pairs(tbBracersData) do
		if tonumber(tbRow["ReqLevel"]) == nNeedLevel then
			if tonumber(tbRow["ReqProp1Type"]) == 3 and tonumber(tbRow["ReqProp1Value"]) == nFactionId then
				if tonumber(tbRow["Quality"]) == nQualityMax then
					tbDefenceTable[#tbDefenceTable + 1] = tbRow;
				end
			end
		end
	end
	--Ь��
	local tbFootData = Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_FOOT) 

	for key,tbRow in pairs(tbFootData) do
		if tonumber(tbRow["ReqLevel"]) == nNeedLevel then
			if tonumber(tbRow["ReqProp1Type"]) == 3 and tonumber(tbRow["ReqProp1Value"]) == nFactionId then
				if tonumber(tbRow["Quality"]) == nQualityMax then
					tbDefenceTable[#tbDefenceTable + 1] = tbRow;
				end
			end
		end
	end
	--����
	local tbNecklaceData = Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_NECKLACE) 

	for key,tbRow in pairs(tbNecklaceData) do
		if tonumber(tbRow["ReqLevel"]) == nNeedLevel then
			--if tonumber(tbRow["ReqProp1Type"]) == 3 and tonumber(tbRow["ReqProp1Value"]) == nFactionId then
				if tonumber(tbRow["Quality"]) == nQualityMax then
					tbDefenceTable[#tbDefenceTable + 1] = tbRow;
				end
			--end
		end
	end
	--����
	local tbPendantData = Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_PENDANT) 

	for key,tbRow in pairs(tbPendantData) do
		if tonumber(tbRow["ReqLevel"]) == nNeedLevel then
			--if tonumber(tbRow["ReqProp1Type"]) == 3 and tonumber(tbRow["ReqProp1Value"]) == nFactionId then
				if tonumber(tbRow["Quality"]) == nQualityMax then
					tbDefenceTable[#tbDefenceTable + 1] = tbRow;
				end
			--end
		end
	end
	--��ָ
	local tbRingData = Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_RING) 

	for key,tbRow in pairs(tbRingData) do
		if tonumber(tbRow["ReqLevel"]) == nNeedLevel then
			--if tonumber(tbRow["ReqProp1Type"]) == 3 and tonumber(tbRow["ReqProp1Value"]) == nFactionId then
				if tonumber(tbRow["Quality"]) == nQualityMax then
					tbDefenceTable[#tbDefenceTable + 1] = tbRow;
				end
			--end
		end
	end
	--��׹
	local tbAmulateData = Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_AMULET) 

	for key,tbRow in pairs(tbAmulateData) do
		if tonumber(tbRow["ReqLevel"]) == nNeedLevel then
			--if tonumber(tbRow["ReqProp1Type"]) == 3 and tonumber(tbRow["ReqProp1Value"]) == nFactionId then
				if tonumber(tbRow["Quality"]) == nQualityMax then
					tbDefenceTable[#tbDefenceTable + 1] = tbRow;
				end
			--end
		end
	end
	--------------------��ȡ��װ------------------------
	--����ֱ�ӻ�ȡ��װ
	----------------------------------------------------
	
	for key,tbRow in pairs(tbWeaponTable) do
		if me.pItem.CountFreeBagCell() >= 1 then
			KItem.AddPlayerItem(me, tonumber(tbRow.Genre), tonumber(tbRow.DetailType), tonumber(tbRow.ParticularType));
		else
			break;
		end
	end
	for key,tbRow in pairs(tbDefenceTable) do
		if me.pItem.CountFreeBagCell() >= 1 then
			KItem.AddPlayerItem(me, tonumber(tbRow.Genre), tonumber(tbRow.DetailType), tonumber(tbRow.ParticularType));
		else
			break;
		end
	end
end

function tbGmCmdHelper:GetCurrency(nNum)
		me.pPlayerPurse.AddMoney(3, nNum * 100);
		me.pPlayerPurse.AddCurrency(1, nNum);
		me.pPlayerPurse.AddCurrency(2, nNum);
		me.pPlayerPurse.AddCurrency(3, nNum);
		me.pPlayerPurse.AddCurrency(4, nNum);
		me.pPlayerPurse.AddCurrency(7, nNum);
		me.pPlayerPurse.AddCurrency(8, nNum);
end

function tbGmCmdHelper:GetPet()
	local tbOpt = {
		{Lang.misc.str84[Lang.Idx],self.GetPetCharacter,self,802};
		{Lang.misc.str85[Lang.Idx],self.GetPetCharacter,self,803};
		{Lang.misc.str86[Lang.Idx],self.GetPetCharacter,self,804};
		{Lang.misc.str87[Lang.Idx],self.GetPetCharacter,self,805};
		{Lang.misc.str78[Lang.Idx], self.GetPet2, self, 0};
		{Lang.misc.str89[Lang.Idx], self.NavBack, self, 0};
	}

	Dialog:SimpleSay(Lang.misc.str90[Lang.Idx], tbOpt);
end

function tbGmCmdHelper:GetPet2()
	local tbOpt = {
		{Lang.misc.str91[Lang.Idx],self.GetPetCharacter,self,806};
		{Lang.misc.str92[Lang.Idx],self.GetPetCharacter,self,807};
		{Lang.misc.str93[Lang.Idx],self.GetPetCharacter,self,808};
		{Lang.misc.str94[Lang.Idx],self.GetPetCharacter,self,809};
		{Lang.misc.str95[Lang.Idx], self.GetPet, self, 0};
	}

	Dialog:SimpleSay(Lang.misc.str90[Lang.Idx], tbOpt);
end

-- function tbGmCmdHelper:GetPetQuality(PetId)
-- 	local tbOpt = {
-- 		{"��ȡһ��Ʒ�ʳ���",self.GetPetCharacter,self,1,PetId};
-- 		{"��ȡ����Ʒ�ʳ���",self.GetPetCharacter,self,2,PetId};
-- 		{"��ȡ����Ʒ�ʳ���",self.GetPetCharacter,self,3,PetId};
-- 		{"��ȡ�ļ�Ʒ�ʳ���",self.GetPetCharacter,self,4,PetId};
-- 		{"��ȡ�弶Ʒ�ʳ���",self.GetPetCharacter,self,5,PetId};
-- 		{"��ȡ����Ʒ�ʳ���",self.GetPetCharacter,self,6,PetId};
-- 		{"����", self.NavBack, self, 0};
-- 	}

-- 	Dialog:SimpleSay("��ѡ��Ҫ��ȡ�ĳ���Ʒ��", tbOpt);
-- end

function tbGmCmdHelper:GetPetCharacter(pIdx)  -- Ʒ��, ����ID
	local tbOpt = {
		{Lang.misc.str96[Lang.Idx],self.GetPetOption,self,1,pIdx};
		{Lang.misc.str97[Lang.Idx],self.GetPetOption,self,2,pIdx};
		{Lang.misc.str98[Lang.Idx],self.GetPetOption,self,3,pIdx};
		{Lang.misc.str99[Lang.Idx],self.GetPetOption,self,4,pIdx};
		{Lang.misc.str110[Lang.Idx],self.GetPetOption,self,5,pIdx};
		{Lang.misc.str111[Lang.Idx],self.GetPetOption,self,6,pIdx};
		{Lang.misc.str112[Lang.Idx],self.GetPetOption,self,7,pIdx};
		{Lang.misc.str89[Lang.Idx], self.NavBack, self, 0};
	}

	Dialog:SimpleSay(Lang.misc.str113[Lang.Idx], tbOpt);
end


function tbGmCmdHelper:GetPetOption(nCharacterId, nPetRepresentId) -- �Ը�Ʒ�ʣ�����ID
	local tbPets = KPet.GetPlayerPetList(me);
	local nPetCapacity = me.GetPetCapacity();
	if #tbPets == nPetCapacity then
		me.SendBlackMsg(Lang.misc.str114[Lang.Idx]);
		return;
	end
	assert(#tbPets < nPetCapacity);
	local pPet = KPet.AddPlayerPet(me, nPetRepresentId, nCharacterId);
	me.SysMsg(Lang.misc.str115[Lang.Idx]..pPet.szName);
end

function tbGmCmdHelper:GetFashion()
	local tbOpt = {
		{Lang.misc.str116[Lang.Idx],self.GetFashionEquip,self,1};
		{Lang.misc.str117[Lang.Idx],self.GetFashionEquip,self,2};
		{Lang.misc.str118[Lang.Idx],self.GetFashionEquip,self,3};
		{Lang.misc.str119[Lang.Idx],self.GetFashionEquip,self,4};
		{Lang.misc.str120[Lang.Idx],self.GetFashionEquip,self,5};
		{Lang.misc.str89[Lang.Idx], self.NavBack, self, 0};
		}

	Dialog:SimpleSay(Lang.misc.str121[Lang.Idx], tbOpt);
end

function tbGmCmdHelper:GetFashionEquip(nIdx)
	local nFactionId = me.GetPrimaryFaction();
	local nSexIdx = me.GetSex();
	--print(nSexIdx);
	local tbOutClothesTable = {};
	local tbOutClothesData = {	
		[1] = Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_HAT), --��ȡñ��	
		[2] = Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_SHOULDER), --��ȡ���
		[3] = Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_BACK), --��ȡ����		
		--Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_BOTTOM) --��ȡ����(�����ݲ�����)
	};
	KItem.AddPlayerItem(me,1,11,nFactionId * 2 + nSexIdx + 8 * (nIdx - 1));--��ȡñ��
	KItem.AddPlayerItem(me,1,12,nFactionId * 2 + nSexIdx + 8 * (nIdx - 1));--��ȡ���
	KItem.AddPlayerItem(me,1,13,nFactionId * 2 + nSexIdx + 8 * (nIdx - 1));--��ȡ����
	--for i = 1, 3 do
	--	for key,tbRow in pairs(tbOutClothesData[i]) do
	--		if tonumber(tbRow["ReqProp1Type"]) == 3 and tonumber(tbRow["ReqProp1Value"]) == nFactionId then
	--			tbOutClothesTable[#tbOutClothesTable + 1] = tbRow;				
	--		end
	--	end
	--end
	--if #tbOutClothesTable < 1 then
	--	Dialog:SimpleSay("û�к��ʵ�װ��");
	--else
	--	for key,tbRow in pairs(tbOutClothesTable) do
	--		print(tonumber(tbRow.Genre), tonumber(tbRow.DetailType), tonumber(tbRow.ParticularType));
	--		if me.pItem.CountFreeBagCell() >= 1 then
	--			KItem.AddPlayerItem(me, tonumber(tbRow.Genre), tonumber(tbRow.DetailType), tonumber(tbRow.ParticularType));
	--		else
	--			break;
	--		end
	--	end
	--end
end

function tbGmCmdHelper:GetWeapon()
	local tbOpt =
	{
			{Lang.misc.str122[Lang.Idx], self.GetWeaponEquip, self, 1},
			{Lang.misc.str123[Lang.Idx], self.GetWeaponEquip, self, 2},
			{Lang.misc.str124[Lang.Idx], self.GetWeaponEquip, self, 4},
			{Lang.misc.str125[Lang.Idx], self.GetWeaponEquip, self, 5},
			{Lang.misc.str126[Lang.Idx], self.GetWeaponEquip, self, 7},
			{Lang.misc.str127[Lang.Idx], self.GetWeaponEquip, self, 8},
			{Lang.misc.str128[Lang.Idx], self.GetWeaponEquip, self, 10},
			{Lang.misc.str129[Lang.Idx], self.GetWeaponEquip, self, 11},
			{Lang.misc.str72[Lang.Idx], self.NavBack, self, 0},
	};
	Dialog:SimpleSay(Lang.misc.str165[Lang.Idx], tbOpt);
end

function tbGmCmdHelper:GetWeaponEquip(nId)
	local tbOpt = {
		{Lang.misc.str130[Lang.Idx], self.GetWeaponEquip2, self, 1,nId},
		{Lang.misc.str131[Lang.Idx], self.GetWeaponEquip2, self, 2,nId},
		{Lang.misc.str132[Lang.Idx], self.GetWeaponEquip2, self, 3,nId},
		{Lang.misc.str133[Lang.Idx], self.GetWeaponEquip2, self, 4,nId},
		{Lang.misc.str134[Lang.Idx], self.GetWeaponEquip2, self, 0,nId},
		{Lang.misc.str72[Lang.Idx], self.NavBack, self, 0},
	};
	Dialog:SimpleSay(Lang.misc.str136[Lang.Idx], tbOpt);
end

function tbGmCmdHelper:GetWeaponEquip2(nQuality,nId)
	local tbOpt = {
		{"1" .. Lang.misc.str135[Lang.Idx], self.GetWeaponEquip3, self, 1,nQuality,nId},
		{"10" .. Lang.misc.str135[Lang.Idx], self.GetWeaponEquip3, self, 10,nQuality,nId},
		{"20" .. Lang.misc.str135[Lang.Idx], self.GetWeaponEquip3, self, 20,nQuality,nId},
		{"30" .. Lang.misc.str135[Lang.Idx], self.GetWeaponEquip3, self, 30,nQuality,nId},
		{"40" .. Lang.misc.str135[Lang.Idx], self.GetWeaponEquip3, self, 40,nQuality,nId},
		{"50" .. Lang.misc.str135[Lang.Idx], self.GetWeaponEquip3, self, 50,nQuality,nId},
		{"60" .. Lang.misc.str135[Lang.Idx], self.GetWeaponEquip3, self, 60,nQuality,nId},
		{Lang.misc.str72[Lang.Idx], self.NavBack, self, 0},
	};
	Dialog:SimpleSay(Lang.misc.str136[Lang.Idx], tbOpt);
end

function tbGmCmdHelper:GetWeaponEquip3(nLevel,nQuality,nId)
	local tbWeaponData = Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_WEAPON);
	local tbFitWeapon = {};
	for key, tbRow in pairs(tbWeaponData) do
		if tonumber(tbRow["ReqLevel"]) == nLevel then
			if tonumber(tbRow["AnimationIndex"]) == nId then
				if nQuality ~= 0 and tonumber(tbRow["Quality"]) == nQuality then
					tbFitWeapon[#tbFitWeapon + 1] = tbRow;
				elseif	nQuality == 0 then
					tbFitWeapon[#tbFitWeapon + 1] = tbRow;
				end
			end
		end
	end
	if #tbFitWeapon < 1 then
		Dialog:SimpleSay(Lang.misc.str137[Lang.Idx]);
	else
		for key, tbRow in pairs(tbFitWeapon) do 
			if me.pItem.CountFreeBagCell() >= 1 then
				KItem.AddPlayerItem(me, tonumber(tbRow.Genre), tonumber(tbRow.DetailType), tonumber(tbRow.ParticularType));
				print(tonumber(tbRow.Genre), tonumber(tbRow.DetailType), tonumber(tbRow.ParticularType),tonumber(tbRow.Quality));
			else
				break;
			end
		end
	end
end

function tbGmCmdHelper:GetDefence()
	local tbOpt =
	{
			{Lang.misc.str134[Lang.Idx], self.GetDefenceEquip, self, 0},
			{Lang.misc.str138[Lang.Idx], self.GetDefenceEquip, self, 2},
			{Lang.misc.str139[Lang.Idx], self.GetDefenceEquip, self, 3},
			{Lang.misc.str140[Lang.Idx], self.GetDefenceEquip, self, 4},    
			{Lang.misc.str141[Lang.Idx], self.GetDefenceEquip, self, 5},
			{Lang.misc.str142[Lang.Idx], self.GetDefenceEquip, self, 6},
			{Lang.misc.str143[Lang.Idx], self.GetDefenceEquip, self, 7},
			{Lang.misc.str144[Lang.Idx], self.GetDefenceEquip, self, 8},
			{Lang.misc.str145[Lang.Idx], self.GetDefenceEquip, self, 9},
			{Lang.misc.str72[Lang.Idx], self.NavBack, self, 0},       
	};                                             
	Dialog:SimpleSay(Lang.misc.str146[Lang.Idx], tbOpt);     
end                                                
                                                   
function tbGmCmdHelper:GetDefenceEquip(nId)         
	local tbOpt = {                                
		{Lang.misc.str13[Lang.Idx], self.GetDefenceEquip2, self, 1,nId},
		{Lang.misc.str14[Lang.Idx], self.GetDefenceEquip2, self, 2,nId},
		{Lang.misc.str15[Lang.Idx], self.GetDefenceEquip2, self, 3,nId},
		{Lang.misc.str16[Lang.Idx], self.GetDefenceEquip2, self, 4,nId},
		{Lang.misc.str134[Lang.Idx], self.GetDefenceEquip2, self, 0,nId},
		{Lang.misc.str72[Lang.Idx], self.NavBack, self, 0},
	};
	Dialog:SimpleSay(Lang.misc.str147[Lang.Idx], tbOpt);
end

function tbGmCmdHelper:GetDefenceEquip2(nQuality,nId)
	local tbOpt = {
		{"1" .. Lang.misc.str135[Lang.Idx], self.GetDefenceEquip3, self, 1,nQuality,nId},
		{"10" .. Lang.misc.str135[Lang.Idx], self.GetDefenceEquip3, self, 10,nQuality,nId},
		{"20" .. Lang.misc.str135[Lang.Idx], self.GetDefenceEquip3, self, 20,nQuality,nId},
		{"30" .. Lang.misc.str135[Lang.Idx], self.GetDefenceEquip3, self, 30,nQuality,nId},
		{"40" .. Lang.misc.str135[Lang.Idx], self.GetDefenceEquip3, self, 40,nQuality,nId},
		{"50" .. Lang.misc.str135[Lang.Idx], self.GetDefenceEquip3, self, 50,nQuality,nId},
		{"60" .. Lang.misc.str135[Lang.Idx], self.GetDefenceEquip3, self, 60,nQuality,nId},
		{Lang.misc.str72[Lang.Idx], self.NavBack, self, 0},
	};
	Dialog:SimpleSay(Lang.misc.str148[Lang.Idx], tbOpt);
end

function tbGmCmdHelper:GetDefenceEquip3(nLevel,nQuality,nId)
	local tbOpt = {
		{Lang.misc.str149[Lang.Idx], self.GetDefenceEquip4, self, 1,nLevel,nQuality,nId},
		{Lang.misc.str150[Lang.Idx], self.GetDefenceEquip4, self, 2,nLevel,nQuality,nId},
		{Lang.misc.str151[Lang.Idx], self.GetDefenceEquip4, self, 3,nLevel,nQuality,nId},
		{Lang.misc.str152[Lang.Idx], self.GetDefenceEquip4, self, 4,nLevel,nQuality,nId},
		{Lang.misc.str72[Lang.Idx], self.NavBack, self, 0},
	};
	Dialog:SimpleSay(Lang.misc.str153[Lang.Idx], tbOpt);
end

function tbGmCmdHelper:GetDefenceEquip4(nFactionId,nLevel,nQuality,nId)
	local tbData = 
	{
		Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_ARMOR);
		Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_BRACERS);
		Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_BELT);
		Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_FOOT);
		Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_NECKLACE);
		Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_RING);
		Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_PENDANT);
		Lib:LoadTabFile(tbGmCmdHelper.tbEQUIP_AMULET);
	};
	local tbFitDefence = {};
	
	if nId and nId ~= 0 then
		if nQuality and nQuality ~= 0 then
			for key,tbRow in pairs(tbData[nId - 1]) do
				if tonumber(tbRow["ReqLevel"]) == nLevel then
					if tonumber(tbRow["Quality"]) == nQuality then
						if tonumber(tbRow["ReqProp1Type"]) == 3 and tonumber(tbRow["ReqProp1Value"]) == nFactionId then
							tbFitDefence[#tbFitDefence + 1] = tbRow;
						end
					end
				end
			end
		elseif nQuality == 0 then
			if tonumber(tbRow["ReqLevel"]) == nLevel then
				if tonumber(tbRow["ReqProp1Type"]) == 3 and tonumber(tbRow["ReqProp1Value"]) == nFactionId then
					tbFitDefence[#tbFitDefence + 1] = tbRow;
				end
			end
		end
	elseif nId == 0 then
		if nQuality and nQuality ~= 0 then
			for i = 1, 8 do
				for key,tbRow in pairs(tbData[i]) do
					if tonumber(tbRow["ReqLevel"]) == nLevel then
						if tonumber(tbRow["Quality"]) == nQuality then
							if tonumber(tbRow["ReqProp1Type"]) == 3 and tonumber(tbRow["ReqProp1Value"]) == nFactionId then
								tbFitDefence[#tbFitDefence + 1] = tbRow;
							end
						end
					end
				end
			end
		elseif nQuality == 0 then
			for i = 1, 8 do
				for key,tbRow in pairs(tbData[i]) do
					if tonumber(tbRow["ReqLevel"]) == nLevel then
						if tonumber(tbRow["ReqProp1Type"]) == 3 and tonumber(tbRow["ReqProp1Value"]) == nFactionId then
							tbFitDefence[#tbFitDefence + 1] = tbRow;
						end
					end
				end
			end
		end			
	end
	if #tbFitDefence < 1 then
		Dialog:SimpleSay(Lang.misc.str154[Lang.Idx]);
	else
		for key, tbRow in pairs(tbFitDefence) do
			if me.pItem.CountFreeBagCell() and me.pItem.CountFreeBagCell() >= 1 then
				KItem.AddPlayerItem(me, tonumber(tbRow.Genre), tonumber(tbRow.DetailType), tonumber(tbRow.ParticularType));
			else
				break;
			end
		end
	end
end


function tbGmCmdHelper:GetDrugs(nNum)
	for i = 1, nNum do
		Item:AddItem(22);
		Item:AddItem(23);
		Item:AddItem(32);
	end
end

function tbGmCmdHelper:AddExp()
	local tbOpt =
		{
			{Lang.misc.str155[Lang.Idx], self.PlayerExp, self, 1000},
			{Lang.misc.str156[Lang.Idx], self.PlayerExp, self, 10000},
			{Lang.misc.str157[Lang.Idx], self.PlayerExp, self, 100000},
			--{"����1000ְҵ����", self.FactionExp, self, 1000},
			--{"����10000ְҵ����", self.FactionExp, self, 10000},
			--{"����100000ְҵ����", self.FactionExp, self, 100000},
			{Lang.misc.str72[Lang.Idx], self.NavBack, self, 0},
		}
	Dialog:SimpleSay(Lang.misc.str158[Lang.Idx], tbOpt);
end

function tbGmCmdHelper:PlayerExp(nNum)
	me.AddExp(nNum);
end

function tbGmCmdHelper:AddYLCoin()
	local tbOpt =
		{
			{Lang.misc.str155[Lang.Idx], self.AddYL, self, 1000},
			{Lang.misc.str156[Lang.Idx], self.AddYL, self, 10000},
			{Lang.misc.str157[Lang.Idx], self.AddYL, self, 100000},
			{Lang.misc.str166[Lang.Idx], self.AddYL, self, 1000000},
			--{"����1000ְҵ����", self.FactionExp, self, 1000},
			--{"����10000ְҵ����", self.FactionExp, self, 10000},
			--{"����100000ְҵ����", self.FactionExp, self, 100000},
			{Lang.misc.str72[Lang.Idx], self.NavBack, self, 0},
		}
	Dialog:SimpleSay(Lang.misc.str159[Lang.Idx], tbOpt);
end

function tbGmCmdHelper:AddYL(nNum)
	me.pPlayerPurse.AddMoney(6, nNum);
end

function tbGmCmdHelper:PlayerLevelUp()
	Dialog:AskNumber(Lang.misc.str160[Lang.Idx], 60 , "GM.tbGM_CMD_HELPER:LevelUp");
end

function tbGmCmdHelper:LevelUp(nInPutLevel)
	me.SetLevel(nInPutLevel);
end

function tbGmCmdHelper:ClearBagRoom()
	local tbAllRoom = {
		Item.BAG_ROOM,
	}
	for _, tbRoom in pairs(tbAllRoom) do
        for _, nRoom in pairs(tbRoom) do
            local tbIdx = me.pItem.FindAllItem(nRoom);
            for i = 1, #tbIdx do
            	--print(tbIdx[i]);
                local pItem = KItem.GetItemObj(tbIdx[i]);
                --print(tbIdx[i],pItem.szName);
                KItem.DelPlayerItem(me,pItem);
            end;
        end;
    end;
end

function tbGmCmdHelper:ClearPetBagRoom()
	local tbIdx = me.pItem.FindAllItem(Item.ROOM_PET);
	for i = 1, #tbIdx do
		--print(tbIdx[i]);
		local pItem = KItem.GetItemObj(tbIdx[i]);
		--print(tbIdx[i],pItem.szName);
		KItem.DelPlayerItem(me,pItem);
	end;
end

function tbGmCmdHelper:GetDailyAward()
	local nCurrentDate = Lib:GetLocalDay();
	if not me.pTask.GetTask(2051,1) or nCurrentDate ~= me.pTask.GetTask(2051,1) then 
		me.pPlayerPurse.AddMoney(2, 100000);
		me.pTask.SetTask(2051,1,nCurrentDate);
	else
		Dialog:SimpleSay(Lang.misc.str161[Lang.Idx]);
	end
end

function tbGmCmdHelper:GoToPK()
	local tbOpt = 
	{
		{Lang.misc.str162[Lang.Idx],self.TeleportToPK,self,1},
		{Lang.misc.str163[Lang.Idx],self.TeleportToPK,self,2},
	}
	Dialog:SimpleSay(Lang.misc.str164[Lang.Idx],tbOpt);
end

function tbGmCmdHelper:TeleportToPK(nIdx)
	me.TeleportTo(unpack(self.tbPKTelePos[nIdx]));
	me.SetCurrentCamp(nIdx);
end

function tbGmCmdHelper:GetPKMedicine()
	KItem.AddPlayerItem(me,17,2,6,1,50);
	KItem.AddPlayerItem(me,17,3,6,1,50);
end


--[[GM������Է� ��������]]
function tbGmCmdHelper:PlayerSetLevel(pName,level)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	pPlayer.SetLevel(level);
end

function tbGmCmdHelper:PlayerSetVipLevel(pName,VipLevel)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	pPlayer.SetVipLevel(VipLevel);
end

function tbGmCmdHelper:PlayerSetKinCamp(pName,Camp)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	pPlayer.SetKinCamp(Camp);
end

function tbGmCmdHelper:PlayerAddMoney(pName,style,money)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	pPlayer.pPlayerPurse.AddMoney(style,money);
end

function tbGmCmdHelper:PlayerSetSpeed(pName,speed)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	pPlayer.SetSpeed(speed);
end

function tbGmCmdHelper:PlayerAddExp(pName,exp)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	pPlayer.AddExp(exp);
end

function tbGmCmdHelper:PlayerSetMaxLife(pName,life)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	pPlayer.SetMaxLife(life);
end

function tbGmCmdHelper:PlayerSetCurrentLifeRecover(pName)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	pPlayer.SetCurrentLife(pPlayer.GetMaxLife());
end

function tbGmCmdHelper:PlayerSetCurrentLifeRecover(pName)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	pPlayer.SetCurrentLife(pPlayer.GetMaxLife());
end

function tbGmCmdHelper:PlayerSetCurrentManaRecover(pName)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	pPlayer.SetCurrentMana(pPlayer.GetMaxMana());
end

function tbGmCmdHelper:PlayerSetMaxMana(pName,mana)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	pPlayer.SetMaxMana(mana);
end

function tbGmCmdHelper:PlayerClearTitleToCharacter(pName)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	Title:ClearTitleToCharacter(pPlayer)
end
--[[����Է����Եȼ�--]]
function tbGmCmdHelper:PlayerClearLevel(pName)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	EightTrigram:ClearLevel(pPlayer)
end

function tbGmCmdHelper:PlayerAddTitleToCharacter(pName,style,num)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	Title:AddTitleToCharacter(pPlayer, style, num, 0)
end

function tbGmCmdHelper:PlayerAddItem(pName,x,y,z,c,num)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	KItem.AddPlayerItem(pPlayer,x,y,z,c,num);
end

function tbGmCmdHelper:PlayerAddAttack(pName,num)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	BufferMagicEffect:Add_Attack(pPlayer,num)
end

function tbGmCmdHelper:PlayerSendSurveyAward(pName,num)
	local pPlayer = KGameBase.GetPlayerByName(pName)
	Player:SendSurveyAward(pPlayer, num)
end