if not MODULE_GAMECENTER then
	return
end

function GlobalData:RefreshRoleRank()
	GlobalExecute({"Rank:RefreshRoleRank"});
end

function GlobalData:RefreshPetLvRank()
	GlobalExecute({"Rank:RefreshPetLvRank"});
end

function GlobalData:RefreshPetFSRank()
	GlobalExecute({"Rank:RefreshPetFSRank"});
end

function GlobalData:RefreshRideRank()
	GlobalExecute({"Rank:RefreshRideRank"});
end

function GlobalData:RefreshMpjjRank()
	GlobalExecute({"Rank:RefreshMpjjRank"});
end

function GlobalData:RefreshTongFSRank()
	GlobalExecute({"Rank:RefreshTongFSRank"});
end

function GlobalData:RefreshTongSrRank()
	GlobalExecute({"Rank:RefreshTongSrRank"});
end

function GlobalData:SaveAllPlayers()
	GlobalExecute({"Rank:SaveAllPlayers"});
end