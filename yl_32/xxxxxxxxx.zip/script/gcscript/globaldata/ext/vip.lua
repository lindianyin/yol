if not MODULE_GAMECENTER then
	return
end

function GlobalData:RefreshSaveBuyCount()
	GlobalExecute({"Vip:RefreshSaveBuyCount"});
end