if not MODULE_GAMECENTER then
	return
end

Include("/script/config/env.lua");