if not (MODULE_GAMECENTER) then
	return
end

Rank.ARENA_RANK 			= 1;
Rank.ROLE_RANK 				= 2;
Rank.PET_LV_RANK 			= 3;
Rank.PET_FIGHTSCORE_RANK 	= 4;
Rank.RIDE_RANK 				= 5;
Rank.MPJJ_RANK 				= 6;
Rank.LG_RANK				= 7; 	-- 炼卦
Rank.SMZC_RANK				= 8;	-- 神魔战场

Rank.TONG_FS_RANK			= 9;
Rank.TONG_SALARY_RANK		= 10;