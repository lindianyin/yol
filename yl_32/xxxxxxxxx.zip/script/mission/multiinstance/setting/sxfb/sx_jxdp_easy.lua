-- 20������ͨ�Ѷȣ����˸��������ļ�

Include("script/mission/multiinstance/multi_def.lua")

if not MultiInstance.tbSetting then
	MultiInstance.tbSetting = {}
end

local tbMultiSetting = MultiInstance.tbSetting;

--���ն���
tbMultiSetting[500]=
   {
	nTimeLimit = 605,  --����ʱ��20����
	nMapId = 500,
    tbBeginPos = {5100,888, 1048576},
	nGameType = MultiInstance.GAME_TYPE.LV_20_EASY,
	nMultiLevel = 20,
	nDifficulty = 1,

    -- �����漰��NPC����
	NPC =
	{
	-- 		���  	npcģ��				�ȼ�(-1Ĭ�����npcpro��)	5��(Ĭ��-1)
	       [1] = {nTemplate = 1000, nLevel = -1, nSeries = -1},		-- ��ʶ
		   [2] = {nTemplate = 1001, nLevel = 35, nSeries = -1},		-- ʯͷ��1   ��
		   [3] = {nTemplate = 1002, nLevel = 35, nSeries = -1},		-- ʯͷ��2   ��
		   [4] = {nTemplate = 1003, nLevel = 35, nSeries = -1},		-- ʯͷ��1
		   [5] = {nTemplate = 1004, nLevel = 35, nSeries = -1},		-- ʯͷ��2
		   [6] = {nTemplate = 1005, nLevel = 35, nSeries = -1},		-- ʯͷ��1
		   [7] = {nTemplate = 1006, nLevel = 35, nSeries = -1},		-- ʯͷ��2
		   [8] = {nTemplate = 1007, nLevel = 35, nSeries = -1},		-- ��ɱ
		   [9] = {nTemplate = 1008, nLevel = 35, nSeries = -1},		-- ��һ���꣨�£�
		   [10] = {nTemplate = 1009, nLevel = 35, nSeries = -1},		-- ʯ��
		   [11] = {nTemplate = 1010, nLevel = -1, nSeries = -1},		-- ǽ����
		   [12] = {nTemplate = 1011, nLevel = 35, nSeries = -1},		-- ��
		   [13] = {nTemplate = 1012, nLevel = 35, nSeries = -1},		-- ��
		   [14] = {nTemplate = 1013, nLevel = -1, nSeries = -1},		-- ����
		   [15] = {nTemplate = 1014, nLevel = 35, nSeries = -1},		-- ���͹�
		   [16] = {nTemplate = 1015, nLevel = 35, nSeries = -1},		-- ��ʯ�꣨�£�
		   [17] = {nTemplate = 1016, nLevel = 35, nSeries = -1},		-- �涫������
		   [18] = {nTemplate = 1019, nLevel = -1, nSeries = -1},		-- �����֣���
		   [19] = {nTemplate = 1020, nLevel = -1, nSeries = -1},		-- ˮ��
		   [20] = {nTemplate = 1021, nLevel = -1, nSeries = -1},		-- ��ʯ�֣����飩
		   [21] = {nTemplate = 1022, nLevel = 35, nSeries = -1},		-- ��ʯ�֣�������
		   [22] = {nTemplate = 1023, nLevel = 35, nSeries = -1},		-- ʯͷ֧ԮBOSS����
		   [23] = {nTemplate = 1024, nLevel = 35, nSeries = -1},		-- ʯͷ֧ԮBOSS����
		   [24] = {nTemplate = 1025, nLevel = 35, nSeries = -1},		-- ʯͷ֧ԮBOSS����
		   [25] = {nTemplate = 1026, nLevel = -1, nSeries = -1},		-- ͸����ɱ
		   [26] = {nTemplate = 1027, nLevel = 35, nSeries = -1},		-- ʯ��
		   [27] = {nTemplate = 1028, nLevel = 35, nSeries = -1},		-- ������ˮ��
		   [28] = {nTemplate = 1029, nLevel = 1, nSeries = -1},		-- ͸��Ŀ��
		   [29] = {nTemplate = 1017, nLevel = 35, nSeries = -1},		-- ʯͷ�����󣡣�
		   [30] = {nTemplate = 1018, nLevel = 35, nSeries = -1},		-- ʯͷ�����ң���
		   [31] = {nTemplate = 1030, nLevel = 35, nSeries = -1},		-- ����ʯ��
	},

    LOCK =
    {
       -- 1�������ܲ��Ĭ��1��Ϊ��ʼ��
		[1] = {nTime = 1, nNum = 0,		-- �ܼ�ʱ
			tbPrelock = {},
			tbStartEvent =
			{
				{MultiInstance.SHOW_NOTICE_MSG, "��������"},
				{MultiInstance.REVIVE_INFO, true, true, false},
				{MultiInstance.SET_TRAP_INVALID, 13, 1},
				{MultiInstance.SET_TRAP_INVALID, 14, 1},
				{MultiInstance.SET_TRAP_INVALID, 15, 1},
			},
			tbUnLockEvent =
			{
			},
		},
		[2] = {nTime = 900, nNum = 0 ,		-- ��С����ʱ��
			tbPrelock = {1},
			tbStartEvent =
			{
                {MultiInstance.TIME_INFO, Lang.mission.str917[Lang.Idx]},
			},
			tbUnLockEvent =
			{
			},
		},
		[3] = {nTime = 0, nNum = 1 ,		-- ����ͨ��
			tbPrelock = {1},
			tbStartEvent =
			{
				{MultiInstance.ADD_NPC, 1, 2, 3, "biaoshi", "biaoshi"},
				{MultiInstance.ADD_NPC, 8, 5, 3, "zisha2", "zisha2"},
				{MultiInstance.ADD_NPC, 28, 1, 3, "mubiao", "mubiao"},
				{MultiInstance.TARGET_INFO, Lang.mission.str918[Lang.Idx]},
				{MultiInstance.SHOW_NOTICE_MSG, Lang.mission.str919[Lang.Idx]},
			},
			tbUnLockEvent =
			{
				{MultiInstance.DEL_NPC,"biaoshi"},
				{MultiInstance.DEL_NPC,"mubiao"},
				--{MultiInstance.ADD_NPC, 3, 1, 5, "shitou_m22", "shitou_m22"},
			   --{MultiInstance.ADD_NPC, 7, 1, 4, "shitou_r22", "shitou_r22"},
				--{MultiInstance.ADD_NPC, 2, 1, 4, "shitou_m1", "shitou_m1", 100, 30, "shitou_timer1",0},                  --ʯͷ
				--{MultiInstance.ADD_NPC, 4, 1, 4, "shitou_l1", "shitou_l1", 100, 20, "shitou_timer3",0},
			},
		},
		[4] = {nTime = 0, nNum = 30 ,		-- ��һС�ڣ��ɼ�"��"
			tbPrelock = {3},
			tbStartEvent =
			{

			    {MultiInstance.ADD_NPC, 9, 4, 4, "gui5", "gui5", 7, 5, "gui5_timer",0},
				{MultiInstance.ADD_NPC, 16, 2, 4, "gui6", "gui6"},
				{MultiInstance.TARGET_INFO, Lang.mission.str918[Lang.Idx]},
				{MultiInstance.SHOW_NOTICE_MSG, Lang.mission.str919[Lang.Idx]},
			},
			tbUnLockEvent =
			{
			{MultiInstance.DEL_NPC,"shitou_m1", "shitou_timer1"},
			{MultiInstance.DEL_NPC,"shitou_m2", "shitou_timer2"},
			{MultiInstance.DEL_NPC,"shitou_l1", "shitou_timer3"},
			{MultiInstance.DEL_NPC,"shitou_l2", "shitou_timer4"},
			{MultiInstance.DEL_NPC,"shitou_r1", "shitou_timer5"},
			{MultiInstance.DEL_NPC,"shitou_r2", "shitou_timer6"},
			{MultiInstance.DEL_NPC,"shitou_m", "shitou_timer7"},
			{MultiInstance.DEL_NPC,"shitou_l", "shitou_timer8"},
			{MultiInstance.DEL_NPC,"shitou_r", "shitou_timer9"},
			{MultiInstance.DEL_NPC,"shitou_r11", "shitou_r11"},
			{MultiInstance.DEL_NPC,"shitou_l11", "shitou_l11"},
			{MultiInstance.DEL_NPC,"shitou_r111", "shitou_r111"},
			{MultiInstance.DEL_NPC,"zhen1"},
			{MultiInstance.DEL_NPC,"zhen2"},
			{MultiInstance.DEL_NPC,"zhen3"},
			{MultiInstance.DEL_NPC,"ding1"},
			{MultiInstance.DEL_NPC,"ding2"},
			{MultiInstance.DEL_NPC,"ding3"},
			{MultiInstance.DEL_NPC,"ding4"},
			{MultiInstance.DEL_NPC,"ding5"},
			{MultiInstance.DEL_NPC,"qiang"},
				{MultiInstance.SET_TRAP_INVALID, 11, 1},

			},
		},
		[5] = {nTime = 10, nNum = 0 ,		-- ʯͷ��Ϊ����ʯͷ��ͬʱ����£�
			tbPrelock = {3},
			tbStartEvent =
			{

			},
			tbUnLockEvent =
			{
			 {MultiInstance.ADD_NPC, 2, 1, 4, "shitou_m1", "shitou_m1", 100, 30, "shitou_timer1",0},                  --ʯͷ
			},
		},
		[6] = {nTime = 0, nNum = 1 ,		-- "��"��������
			tbPrelock = {3},
			tbStartEvent =
			{
			},
			tbUnLockEvent =
			{
			},
		},
		[7] = {nTime = 0, nNum = 1 ,		-- "��"��������
			tbPrelock = {3},
			tbStartEvent =
			{
			},
			tbUnLockEvent =
			{
			},
		},
		[8] = {nTime = 0, nNum = 1 ,		-- "��"��������
			tbPrelock = {3},
			tbStartEvent =
			{
			},
			tbUnLockEvent =
			{
			},
		},
		[9] = {nTime = 0, nNum = 1 ,		-- "��"��������
			tbPrelock = {3},
			tbStartEvent =
			{
			},
			tbUnLockEvent =
			{
			},
		},
		[10] = {nTime = 0, nNum = 1 ,		-- "��"��������
			tbPrelock = {3},
			tbStartEvent =
			{
			},
			tbUnLockEvent =
			{
			},
		},
		[11] = {nTime = 0, nNum = 1 ,		-- �ڶ�С�ڡ�������š�
			tbPrelock = {4},
			tbStartEvent =
			{
				--{MultiInstance.ADD_NPC, 10, 18, 11, "gui", "gui"},
				{MultiInstance.ADD_NPC, 15, 1, 11, "juxing", "juxing"},
				--{MultiInstance.ADD_NPC, 10, 8, 11, "gui1", "gui1"},
				{MultiInstance.TARGET_INFO, Lang.mission.str920[Lang.Idx]},
				{MultiInstance.SHOW_NOTICE_MSG, Lang.mission.str921[Lang.Idx]},
			},
			tbUnLockEvent =
			{

			 {MultiInstance.DEL_NPC, "gui2"},
			{MultiInstance.DEL_NPC, "gui22"},
			{MultiInstance.DEL_NPC, "zhadan",},
			{MultiInstance.DEL_NPC,"qiang1"},
			{MultiInstance.SET_TRAP_INVALID, 12, 1},
			},
		},
		[12] = {nTime = 0, nNum = 18 ,		-- �ڶ�С�ڡ����Ī��
			tbPrelock = {11},
			tbStartEvent =
			{

			},
			tbUnLockEvent =
			{
			},
		},
		[13] = {nTime = 0, nNum = 1 ,		-- ��������
			tbPrelock = {4},
			tbStartEvent =
			{
			},
			tbUnLockEvent =
			{
            -- trapʧЧ
			},
		},
		[14] = {nTime = 0, nNum = 1 ,		-- ������
			tbPrelock = {13},
			tbStartEvent =
			{
			},
			tbUnLockEvent =
			{

			},
		},
		[15] = {nTime = 0, nNum = 1 ,		-- ����С�ڣ�б��ʯͷ��ʼ��
			tbPrelock = {17},
			tbStartEvent =
			{
			},
			tbUnLockEvent =
			{
			},
		},
		[16] = {nTime = 1, nNum = 0 ,		-- ������
			tbPrelock = {11},
			tbStartEvent =
			{

			},
			tbUnLockEvent =
			{
			},
		},
		[17] = {nTime = 0, nNum = 1 ,		-- ��������ʼ��ʯͷ
			tbPrelock = {16},
			tbStartEvent =
			{
			},
			tbUnLockEvent =
			{
			},
		},
		[18] = {nTime = 0, nNum = 12 ,		-- ���Ľڣ���ʯ���������ֺܶ��
			tbPrelock = {17},
			tbStartEvent =
			{
			},
			tbUnLockEvent =
			{
			},
		},
		[19] = {nTime = 0, nNum = 1 ,		-- ������
			tbPrelock = {1},
			tbStartEvent =
			{
			},
			tbUnLockEvent =
			{

			},
		},
		[20] = {nTime = 0, nNum = 0 ,		-- ������
			tbPrelock = {19},
			tbStartEvent =
			{
			},
			tbUnLockEvent =
			{
			},
		},
		[21] = {nTime = 2, nNum = 0 ,		-- ������
			tbPrelock = {20},
			tbStartEvent =
			{
			},
			tbUnLockEvent =
			{
			{MultiInstance.DEL_NPC,"baohu1"},
			{MultiInstance.DEL_NPC,"baohu2"},
			{MultiInstance.DEL_NPC,"baohu3"},
			{MultiInstance.DEL_NPC,"baohu4"},
			},
		},
		[22] = {nTime = 0, nNum = 1 ,		-- ��ͨ����������ʱ�䵹��ʱ��ɱ�ָ�����
			tbPrelock = {11},
			tbStartEvent =
			{
			{MultiInstance.ADD_NPC, 19, 1, 22, "shuijing", "shuijing"},
			{MultiInstance.ADD_NPC, 8, 3, 22, "zisha1", "zisha1"},
			{MultiInstance.SHOW_NOTICE_MSG, Lang.mission.str922[Lang.Idx]},
			},
			tbUnLockEvent =
			{
			},
		},
		[23] = {nTime = 5, nNum = 0 ,		-- ��ͨ����������ʱ�䵹��ʱ��ɱ�ָ�����
			tbPrelock = {22},
			tbStartEvent =
			{
			{MultiInstance.ADD_NPC, 20, 1, 23, "jushiguai", "jushiguai"},
			{MultiInstance.NPC_BUBBLE, "jushiguai",Lang.mission.str923[Lang.Idx], 2},
			{MultiInstance.TARGET_INFO, Lang.mission.str924[Lang.Idx]},
			{MultiInstance.SHOW_NOTICE_MSG, Lang.mission.str922[Lang.Idx]},
			},
			tbUnLockEvent =
			{
			{MultiInstance.DEL_NPC,"jushiguai"},
			},
		},
		[24] = {nTime = 5, nNum = 0 ,		-- ��ͨ����������ʱ�䵹��ʱ��ɱ�ָ�����
			tbPrelock = {22},
			tbStartEvent =
			{

			},
			tbUnLockEvent =
			{
			{MultiInstance.ADD_NPC, 26, 8, 24, "gui1", "gui1"},
			},
		},
		[25] = {nTime = 0, nNum = 1 ,		-- ���Ľ�BOSS����ʯ��
			tbPrelock = {23},
			tbStartEvent =
			{
                {MultiInstance.ADD_NPC, 21, 1, 25, "jushiguai1", "jushiguai"},                     --BOSS����
				{MultiInstance.TARGET_INFO, Lang.mission.str925[Lang.Idx]},
				{MultiInstance.SHOW_NOTICE_MSG, Lang.mission.str926[Lang.Idx]},

			},
			tbUnLockEvent =
			{
			{MultiInstance.DEL_ALL_NPC},
			},
		},
		[26] = {nTime = 0, nNum = 1 ,		-- ��ͨ����������ʱ�䵹��ʱ��ɱ�ָ�����
			tbPrelock = {23},
			tbStartEvent =
			{
                {MultiInstance.ADD_NPC, 25, 3, 26, "beisha", "beisha"},
			},
			tbUnLockEvent =
			{
			{MultiInstance.DEL_NPC,"beisha"},
			{MultiInstance.SHOW_NOTICE_MSG, Lang.mission.str927[Lang.Idx]},
			},
		},
		[27] = {nTime = 0, nNum = 3 ,		-- ��ͨ����������ʱ�䵹��ʱ��ɱ�ָ�����
			tbPrelock = {26},
			tbStartEvent =
			{
			    {MultiInstance.ADD_NPC, 31, 3, 27, "fangyu", "fangyu"},
			},
			tbUnLockEvent =
			{
			{MultiInstance.CLEAR_NPC_BUFF, "jushiguai1", 1094},
			{MultiInstance.CLEAR_NPC_BUFF, "jushiguai1", 1093},
			{MultiInstance.CLEAR_NPC_BUFF, "jushiguai1", 1106},
			},
		},
		[28] = {nTime = 0, nNum = 1 ,		-- ��ͨ����������ʱ�䵹��ʱ��ɱ�ָ�����
			tbPrelock = {26},
			tbStartEvent =
			{
                {MultiInstance.ADD_NPC, 25, 3, 28, "beisha1", "beisha"},
			},
			tbUnLockEvent =
			{
			{MultiInstance.DEL_NPC,"beisha1"},
			{MultiInstance.SHOW_NOTICE_MSG, Lang.mission.str927[Lang.Idx]},
			},
		},
		[29] = {nTime = 0, nNum = 3 ,		-- ��ͨ����������ʱ�䵹��ʱ��ɱ�ָ�����
			tbPrelock = {28},
			tbStartEvent =
			{
			{MultiInstance.ADD_NPC, 31, 3, 29, "fangyu", "fangyu"},
			},
			tbUnLockEvent =
			{
			{MultiInstance.CLEAR_NPC_BUFF, "jushiguai1", 1094},
			{MultiInstance.CLEAR_NPC_BUFF, "jushiguai1", 1093},
			{MultiInstance.CLEAR_NPC_BUFF, "jushiguai1", 1106},
			},
		},
		[30] = {nTime = 0, nNum = 1 ,		-- ��ͨ����������ʱ�䵹��ʱ��ɱ�ָ�����
			tbPrelock = {28},
			tbStartEvent =
			{
				{MultiInstance.DEL_NPC,"gui2","gui_timer"},
                {MultiInstance.ADD_NPC, 25, 3, 30, "beisha2", "beisha"},
			},
			tbUnLockEvent =
			{
			{MultiInstance.DEL_NPC,"beisha2"},
			{MultiInstance.SHOW_NOTICE_MSG, Lang.mission.str928[Lang.Idx]},
			},
		},
		[31] = {nTime = 0, nNum = 3 ,		-- �ٻ�����ʯͷ
			tbPrelock = {30},
			tbStartEvent =
			{
				 {MultiInstance.ADD_NPC, 31, 3, 31, "fangyu", "fangyu"},
			},
			tbUnLockEvent =
			{
			{MultiInstance.CLEAR_NPC_BUFF, "jushiguai1", 1094},
			{MultiInstance.CLEAR_NPC_BUFF, "jushiguai1", 1093},
			{MultiInstance.CLEAR_NPC_BUFF, "jushiguai1", 1106},
			},
		},
		[32] = {nTime = 0, nNum = 1 ,		-- ��ͨ����������ʱ�䵹��ʱ��ɱ�ָ�����
			tbPrelock = {30},
			tbStartEvent =
			{
                {MultiInstance.ADD_NPC, 25, 3, 32, "beisha3", "beisha"},
			},
			tbUnLockEvent =
			{
		        {MultiInstance.DEL_NPC,"beisha3"},
		        {MultiInstance.DEL_NPC,"shitou","shitou_timer"},
				{MultiInstance.SHOW_NOTICE_MSG, Lang.mission.str928[Lang.Idx]},
			},
		},
		[33] = {nTime = 10, nNum = 0 ,		-- ���ӵ�ǰ�沽�裨��ʯͷ��
			tbPrelock = {5},
			tbStartEvent =
			{

			},
			tbUnLockEvent =
			{
			-- {MultiInstance.ADD_NPC, 3, 1, 5, "shitou_m", "shitou_m", 100, 30, "shitou_timer7",0},
			{MultiInstance.ADD_NPC, 30, 1, 4, "shitou_r111", "shitou_r11", 100, 50, "shitou_r111",0},
			},
		},
		[34] = {nTime = 0, nNum = 1 ,		-- ������
			tbPrelock = {4},
			tbStartEvent =
			{
			},
			tbUnLockEvent =
			{              -- trapʧЧ
			},
		},
		[35] = {nTime = 1, nNum = 0 ,		-- ��ͨ����������ʱ�䵹��ʱ��ɱ�ָ�����
			tbPrelock = {25},
			tbStartEvent =
			{
			{MultiInstance.SET_TRAP_INVALID, 11, 0},      -- trap���ڹؿ�����ǰһ��Ҫ�ָ���Ч
			{MultiInstance.SET_TRAP_INVALID, 12, 0},
			{MultiInstance.SET_TRAP_INVALID, 13, 0},
			{MultiInstance.SET_TRAP_INVALID, 14, 0},
			{MultiInstance.SET_TRAP_INVALID, 15, 0},

			},
			tbUnLockEvent =
			{
				{MultiInstance.DO_SCRIPT, "self.bCanTakeAward = 1"},
			},
		},
		[36] = {nTime = 5, nNum = 0 ,		-- ͨ�������ܼ�ʱ
			tbPrelock = {35},
			tbStartEvent =
			{
				{MultiInstance.TARGET_INFO, Lang.mission.str857[Lang.Idx]},
				{MultiInstance.TIME_INFO, Lang.mission.str929[Lang.Idx], 4},
			},
			tbUnLockEvent =
			{
				{MultiInstance.DO_SCRIPT, "self.bFinish = 1"},
			},
		}
    }
}

