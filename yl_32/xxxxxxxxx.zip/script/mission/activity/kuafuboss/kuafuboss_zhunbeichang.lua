Include("script/mission/activity/activitystep.lua")
Include("script/mission/activity/activitydef.lua")

Activity.KUAFUBOSS_ZHUNBEICHANG = Lib:NewClass(Activity.ActivityStep);

Activity.ACTSTEP_FACTORY[Activity.STEP_TYPE.KUAFUBOSS_ZHUNBEICHANG] = Activity.KUAFUBOSS_ZHUNBEICHANG -- ע�ᵽ�����

local KUAFUBOSS_ZHUNBEICHANG = Activity.KUAFUBOSS_ZHUNBEICHANG

--[[
function KUAFUBOSS_ZHUNBEICHANG:OnCharacterLeaveScene(nCharacterId)
	local pPlayer = KGameBase.GetPlayerById(nCharacterId);
	if pPlayer and pPlayer.dwSceneTemplateId == self.tbPos[1] then
	    self:KickPlayer(nCharacterId, 1)
	end
	print("OnCharacterLeaveScene", pPlayer.dwSceneTemplateId, self.tbPos[1]);
	--print("���boss���뿪������������", nCharacterId, pPlayer.dwSceneTemplateId, self.tbPos[1]);
end]]--