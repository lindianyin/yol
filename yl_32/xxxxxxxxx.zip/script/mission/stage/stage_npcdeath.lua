
-- 
local StageNpc_Death = Npc:GetClass("stagenpc_death")

function StageNpc_Death:OnDeath(pKiller, pNpc)
	Stage:NpcUnLock(pNpc);
end
