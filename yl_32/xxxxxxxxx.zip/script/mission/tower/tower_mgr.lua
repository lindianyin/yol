Include("script/mission/tower/tower_base.lua")

Tower.tbGames = {};
Tower.tbFirstEnter = {};
Tower.tbTotalExp = {};		-- �ۼƻ�õľ��齱��

function Tower:c2s_DoChallenge(pPlayer)
	self:DoChallenge(pPlayer);
end

function Tower:DoChallenge(pPlayer)
	local nLayer = pPlayer.GetTowerLayer() + 1;
	
	if not self.tbSetting[nLayer] then
		assert(false);
	end
	
	local tbPos = self.tbSetting[nLayer].tbBeginPos;
	local nMapId = self.tbSetting[nLayer].nMapId;
	
	pPlayer.SetMissionState(PVEMatch.STATE_NONE);		-- ����״̬
	
	Pet:GetDownRide(pPlayer);	-- ����
	
	pPlayer.TeleportTo(nMapId, tbPos[1], tbPos[2], tbPos[3], 1);
end

function Tower:SetStartLayer(pPlayer, nLayer)
	local tbTempTable = pPlayer.GetCharacterTempTable();
	if not tbTempTable.tbTowerInfo then
		tbTempTable.tbTowerInfo = {};
	end
	
	local tbTowerInfo = tbTempTable.tbTowerInfo;
	tbTowerInfo.nStartLayer = nLayer;
end

function Tower:GetStartLayer(pPlayer)
	local nStartLayer = 0;
	local tbTempTable = pPlayer.GetCharacterTempTable();
	local tbTowerInfo = tbTempTable.tbTowerInfo;
	
	nStartLayer = tbTowerInfo.nStartLayer;
	--tbTowerInfo.nStartLayer = nil;
	
	return nStartLayer;
end

function Tower:SetFailedFlag(pPlayer)
	local tbTempTable = pPlayer.GetCharacterTempTable();
	if not tbTempTable.tbTowerInfo then
		tbTempTable.tbTowerInfo = {};
	end
	
	local tbTowerInfo = tbTempTable.tbTowerInfo;
	if not tbTowerInfo.nFailed then
		tbTowerInfo.nFailed = 1;
	end
end

function Tower:GetFailedFlag(pPlayer)
	local nFailed = 0;
	local tbTempTable = pPlayer.GetCharacterTempTable();
	local tbTowerInfo = tbTempTable.tbTowerInfo;
	
	if tbTowerInfo then
	    nFailed = tbTowerInfo.nFailed;
	    tbTowerInfo.nFailed = nil;
	end
	
	return nFailed;
end

function Tower:OnEnterScene(dwCharacterId)
	local pPlayer = KGameBase.GetCharacterById(dwCharacterId);
	
	if pPlayer.IsNpc() == 1 then
		return;
	end
	
	local nMapId = pPlayer.dwSceneTemplateId;
	if KScene.GetSceneTypeName(nMapId) == "city" then
		Player:SetTempReviveFunc(pPlayer, nil);
	end
	
	if KScene.GetSceneTypeName(nMapId) ~= "tower" then
		return;
	end
	
	local nLayer = pPlayer.GetTowerLayer() + 1;
	
	local pGame = self.tbGames[dwCharacterId];
	
	if pGame then
		return;
	end
	
	pGame = Lib:NewClass(self.BaseGame);
	pGame:InitGame(nMapId, pPlayer.dwSceneId, pPlayer.dwId, self.tbSetting[nLayer]);
	pGame:JoinPlayer(pPlayer, 1);
	
	if not self.tbTotalExp[dwCharacterId] then
		self.tbTotalExp[dwCharacterId] = 0;
	end
	
	if not self.tbFirstEnter[dwCharacterId] then
		self:SetStartLayer(pPlayer, nLayer);
		self.tbFirstEnter[dwCharacterId] = 1;
		self:SetRewardInfo(pPlayer, nLayer - 1);
	end
	
	self.tbGames[dwCharacterId] = pGame;
	
	Player:SetTempReviveFunc(pPlayer, {"Tower:OnDeath", pPlayer});
end

function Tower:OnDeath(pPlayer)
	local nMapId = pPlayer.dwSceneTemplateId;
	if KScene.GetSceneTypeName(nMapId) ~= "tower" then
		return;
	end
	
	self:OnFailed(pPlayer);
end

function Tower:ShowFailedPanel(nPlayerId)
	-- ��ʧ�����
	local pPlayer = KGameBase.GetPlayerById(nPlayerId);
	if not pPlayer then
		return;
	end
	
	local nStartLayer = self:GetStartLayer(pPlayer);
	pPlayer.CallClientScript({"YoulongApp.Represent.QRepresentClientScript:ShowTowerFailPanel", nStartLayer});
	
	return 0;
end

function Tower:OnFailed(pPlayer)
	self:SetFailedFlag(pPlayer);
	self:ShowFailedPanel(pPlayer.dwId);
	Timer:Register(10 * Env.GAME_FPS, self.DoLeaveGame, self, pPlayer.dwId);
end

function Tower:c2s_DoLeaveGame(pPlayer)
	self:DoLeaveGame(pPlayer.dwId);
end

function Tower:DoLeaveGame(nPlayerId)
	local pGame = self.tbGames[nPlayerId];
	
	if pGame then
		pGame:CloseGame(1);
	end
	
	return 0;
end

function Tower:GoNextLayer(nOwnerId)
	local pPlayer = KGameBase.GetPlayerById(nOwnerId);
	local pGame = self.tbGames[pPlayer.dwId];
	
	self:OnChallengeLayerDone(pPlayer);
	
	pGame:CloseGame();
	
	local nLayer = pPlayer.GetTowerLayer() + 1;
	pPlayer.SetTowerLayer(nLayer);
	KTower.SyncTowerRank(nOwnerId, nLayer);
	Player:FullHealth(pPlayer);		-- ����Ѫ
	
	pPlayer.CallClientScript({"YoulongApp.Represent.QRepresentClientScript:OnNextLayerBegin"});
end

function Tower:OnAllFinish(nOwnerId)
	local pPlayer = KGameBase.GetPlayerById(nOwnerId);
	local pGame = self.tbGames[pPlayer.dwId];
	
	self:OnChallengeLayerDone(pPlayer);
	
	pGame:CloseGame(1);
	
	local nLayer = pPlayer.GetTowerLayer() + 1;
	pPlayer.SetTowerLayer(nLayer);
	KTower.SyncTowerRank(nOwnerId, nLayer);
end

function Tower:c2s_DoStartNextLayer(pPlayer)
	self:DoStartNextLayer(pPlayer);
end

function Tower:DoStartNextLayer(pPlayer)
	local nLayer = pPlayer.GetTowerLayer();
	
	local nTargetMapId = self.tbSetting[nLayer + 1].nMapId;
	
	-- �����һ��������ͼһ����ֱ��ˢ����������Ȼ��ʼ�������ȴ���
	if nTargetMapId == pPlayer.dwSceneTemplateId then
		local tbPos = self.tbSetting[nLayer].tbBeginPos;
		pPlayer.TeleportTo(pPlayer.dwSceneId, tbPos[1], tbPos[2], tbPos[3], 1);
		self:OnEnterScene(pPlayer.dwId);
		self:DoStartGame(pPlayer);
	else
		self:DoChallenge(pPlayer);
	end
end

function Tower:DoStartGame(pPlayer)
	local pGame = self.tbGames[pPlayer.dwId];
	if pGame then
		pGame:StartGame();
	end
end

function Tower:c2s_StartGame(pPlayer)
	self:DoStartGame(pPlayer);
end

function Tower:NpcUnLock(pNpc)
	local tbTmp = pNpc.GetTempTable("Tower")
	if not tbTmp then
		return 0;
	end
	if (not tbTmp.tbTower) or (not tbTmp.nLock) then
		return 0;
	end
	if not tbTmp.tbTower.tbLock[tbTmp.nLock] then
		return 0;
	end
	
	tbTmp.tbTower.tbLock[tbTmp.nLock]:UnLockMulti();
	
	-- KK:���ݸ����Instance,��¼ɱ�����ı�
	-- �ж�����ɱ����Ҫ���Ƿ����0, ������TargetInfo
	if (tbTmp.tbTower.tbLock[tbTmp.nLock]:IsClose() ~= 1) then
		if (tbTmp.tbTower.tbLock[tbTmp.nLock].nInitMultiNum > 0) then
			-- ����targetInfo����ʾɱ������
			tbTmp.tbTower:SyncTargetInfo(tbTmp.tbTower.szTargetInfo, tbTmp.nLock);
		end
	end
end

-- �õ�ÿһ��Ӧ�õõ��ľ�����ֵ
function Tower:GetLayerTotalExp(nLayer, nPlayerLevel)
	-- 60���ܾ���
	local nTotalExp = KAward.GetExpByLevel(Tower.EXP_AWARD_ID, nPlayerLevel + 1);
	local tbCfg = Tower.LayerCfgs[nLayer];
	local nLayerExp = math.floor(nTotalExp * tbCfg.nExpPercent / Tower.nTotalExpPercent);
	return nLayerExp;
end

function Tower:OnChallengeLayerDone(pPlayer)
	-- ����ǰ�����ս����
	local nCurLayer = pPlayer.GetTowerLayer() + 1;
	local tbCfg = Tower.LayerCfgs[nCurLayer];
	
	local nTotalExp = Tower:GetLayerTotalExp(nCurLayer, pPlayer.GetLevel());
	local nExp = math.floor(nTotalExp / 2);
	pPlayer.AddExp(nExp);
	self.tbTotalExp[pPlayer.dwId] = self.tbTotalExp[pPlayer.dwId] + nTotalExp;
	
	pPlayer.pPlayerPurse.AddMoney(Purse.EM_MONEY_SILVER, tbCfg.nMoney);
	
	if nCurLayer == 20 then
		Target:DoTarget(pPlayer, 1);
	elseif nCurLayer == 40 then
		Target:DoTarget(pPlayer, 3);
	elseif nCurLayer == 60 then
		Target:DoTarget(pPlayer, 6);
	end
	
	if nCurLayer == 10 then
		KChat.BroadcastNoticeMsg(string.format(Lang.mission.str1053[Lang.Idx], pPlayer.szName));
	elseif nCurLayer == 20 then
		KChat.BroadcastNoticeMsg(string.format(Lang.mission.str1054[Lang.Idx], pPlayer.szName));
	elseif nCurLayer == 30 then
		KChat.BroadcastNoticeMsg(string.format(Lang.mission.str1055[Lang.Idx], pPlayer.szName));
	elseif nCurLayer == 40 then
		KChat.BroadcastNoticeMsg(string.format(Lang.mission.str1056[Lang.Idx], pPlayer.szName));
	elseif nCurLayer == 50 then
		KChat.BroadcastNoticeMsg(string.format(Lang.mission.str1057[Lang.Idx], pPlayer.szName));
	elseif nCurLayer == 60 then
		KChat.BroadcastNoticeMsg(string.format(Lang.mission.str1058[Lang.Idx], pPlayer.szName));
	end
end

function Tower:SetRewardInfo(pPlayer, nLayer)
	if not nLayer then
		nLayer = pPlayer.GetTowerLayer() + 1;
	end
	
	local szInfo = "";
	local nTotalMoney = 0;
	local nStartLayer = self:GetStartLayer(pPlayer);
	local nNextLevel = pPlayer.GetLevel() + 1;
	
	for i = nStartLayer, nLayer do
		local tbCfg = Tower.LayerCfgs[i];
		nTotalMoney = nTotalMoney + tbCfg.nMoney;
	end
	
	szInfo = string.format(Lang.mission.str1059[Lang.Idx], nTotalMoney, self.tbTotalExp[pPlayer.dwId]);
	
	pPlayer.CallClientScript({"QClientScript.Mission:SetMissionExInfo", szInfo});
end

function Tower:LeaveGame(pPlayer)
	self:SetFailedFlag(pPlayer);
	local pGame = self.tbGames[pPlayer.dwId];
	if pGame then
		pGame:CloseGame(1);
	end
end

function Tower:OnLogout(dwCharacterId)
	local pPlayer = KGameBase.GetPlayerById(dwCharacterId);
	if not pPlayer then
		return;
	end
	
	local nMapId = pPlayer.dwSceneTemplateId;
	if KScene.GetSceneTypeName(nMapId) ~= "tower" then
		return;
	end
	
	local pGame = self.tbGames[pPlayer.dwId];
	if pGame then
		pGame:CloseGame(1);
	end
end

CallCenter:RegisterGlobalEvent(KOBJEVENT.emKOBJEVENTTYPE_PLAYER_LOGOUT, Tower.OnLogout, Tower)
CallCenter:RegisterGlobalEvent(KOBJEVENT.emKOBJEVENTTYPE_CHARACTER_ENTER_SCENE, Tower.OnEnterScene, Tower);