
Rank.ARENA_RANK 			= 1;
Rank.ROLE_RANK 				= 2;
Rank.PET_LV_RANK 			= 3;
Rank.PET_FIGHTSCORE_RANK 	= 4;
Rank.RIDE_RANK 				= 5;
Rank.MPJJ_RANK 				= 6;
Rank.LG_RANK				= 7; 	-- 炼卦
Rank.SMZC_RANK				= 8;	-- 神魔战场
Rank.ALL_RANK 				= 9;	--全部排行榜

Rank.TONG_FS_RANK			= 7;
Rank.TONG_SALARY_RANK		= 8;

Rank.RANK_AWARD_SPEN = (7 * 24 * 3600)

-- 排行榜刷新时间
Rank.tbRefreshTime =
{
	[Rank.ROLE_RANK] = 				{ { hour=0, min=0, sec=0}, "Rank:RefreshRoleRank" },
	[Rank.PET_LV_RANK] = 			{ { hour=0, min=0, sec=0}, "Rank:RefreshPetLvRank" },
	[Rank.PET_FIGHTSCORE_RANK] = 	{ { hour=0, min=0, sec=0}, "Rank:RefreshPetFSRank" },
	[Rank.RIDE_RANK] = 				{ { hour=0, min=0, sec=0}, "Rank:RefreshRideRank" },
	[Rank.MPJJ_RANK] = 				{ { hour=0, min=0, sec=0}, "Rank:RefreshMpjjRank" },
	[Rank.LG_RANK] = 				{ { hour=0, min=0, sec=0}, "Rank:RefreshLGRank" },
	[Rank.SMZC_RANK] = 				{ { hour=0, min=0, sec=0}, "Rank:RefreshSmzcRank" },
	[Rank.TONG_FS_RANK] = 			{ { hour=0, min=0, sec=0}, "Rank:RefreshTongFSRank" },
	[Rank.TONG_SALARY_RANK] = 		{ { hour=0, min=0, sec=0}, "Rank:RefreshTongSrRank" },
	[Rank.ALL_RANK] = 				{ { min=10, sec=0}, "Rank:RefreshAllRank" },
	[Rank.ALL_RANK] = 				{ { min=20, sec=0}, "Rank:RefreshAllRank" },
	[Rank.ALL_RANK] = 				{ { min=30, sec=0}, "Rank:RefreshAllRank" },
	[Rank.ALL_RANK] = 				{ { min=40, sec=0}, "Rank:RefreshAllRank" },
	[Rank.ALL_RANK] = 				{ { min=50, sec=0}, "Rank:RefreshAllRank" },
	[Rank.ALL_RANK] = 				{ { min=00, sec=0}, "Rank:RefreshAllRank" },
}