-----------------------------------------------------
--�ļ���		��	ktaskscript.lua
--������		��	zhengyuhua
--����ʱ��		��	2008-01-08
--��������		��	������չ�ű���
------------------------------------------------------
if MODULE_GC_SERVER then
	return
end

local TASK_AWARD_TIP = {};
TASK_AWARD_TIP.exp = function(tbAward)
	return Lang.task.str36 .."��<color=green>"..tostring(tbAward.varValue).."<color>";
end

TASK_AWARD_TIP.money = function(tbAward)
	return Lang.task.str37 .."��<color=green>"..tostring(tbAward.varValue).."<color>";
end

TASK_AWARD_TIP.bindmoney = function(tbAward)
	if (type(tbAward.varValue) == "number") then
		return Lang.task.str38 .."��<color=green>"..tostring(tbAward.varValue).."<color>";
	else
		return tbAward.szDesc;
	end
end

TASK_AWARD_TIP.activemoney = function(tbAward)
	return Lang.task.str39 .."��<color=green>"..tostring(tbAward.varValue).."<color>";
end

TASK_AWARD_TIP.gatherpoint = function(tbAward)
	return Lang.task.str40 .."��<color=green>"..tbAward.varValue.."<color>";
end

TASK_AWARD_TIP.linktask_repute = function(tbAward)
	return	Lang.task.str41 .."��<color=green>"..tbAward.varValue[3].."<color>";
end

TASK_AWARD_TIP.linktask_cancel = function(tbAward)
	return	"<color=green>".. Lang.task.str42  .. "<color>";
end

TASK_AWARD_TIP.makepoint = function(tbAward)
	return Lang.task.str43[Lang.Idx] .. "��<color=green>"..tbAward.varValue.."<color>";
end

TASK_AWARD_TIP.title = function(tbAward)
	local tbTitle = KPlayer.GetTitleLevelAttr(tbAward.varValue[1], tbAward.varValue[2], tbAward.varValue[3]);
	local szDesc = tbTitle.szTitleName or "";
	return Lang.task.str44 .."��<color=green>"..szDesc.."<color>";
end

TASK_AWARD_TIP.repute = function(tbAward)
	local tbRepute = KPlayer.GetReputeInfo();
	local szReputeDesc = tbRepute[tbAward.varValue[1]][tbAward.varValue[2]].szName
	return Lang.task.str45 .."��<color=green>"..szReputeDesc.." "..tbAward.varValue[3]..Lang.task.str46 .."<color>";
end


-- ��ȡĳ������tip
function KTask.GetAwardTip(tbAward)
	local fncTip = TASK_AWARD_TIP[tbAward.szType];
	if not fncTip then
		return tbAward.szDesc;
	end
	local szTip	= "";
	if type(fncTip) == "function" then
		szTip = fncTip(tbAward);
	end
	return szTip;
end
