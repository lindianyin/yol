

-- ���ﵰ
local tbPetCard = Item:GetClass("pet_card");

function tbPetCard:OnUse()

	local tbPets = KPet.GetPlayerPetList(me);
	local nPetCapacity = me.GetPetCapacity();
	
	if #tbPets == nPetCapacity then
		me.SendBlackMsg(Lang.pet.str50[Lang.Idx]);
		return;
	end
	
	assert(#tbPets < nPetCapacity);
	-- ��Ʒ���Ӳ���ע��: 1 ������ 2����Ʒ�� 3�Ը�
	local nType = tonumber(it.GetExtParam(1))--KUnify.MathRandom(it.GetExtParam(1), it.GetExtParam(2));
	local nQuality = tonumber(it.GetExtParam(2))--Lib:RandProb(tbRate); -- Ʒ��
	assert(nQuality);
	local nCharacter = tonumber(it.GetExtParam(3))--KUnify.MathRandom(it.GetExtParam(3), it.GetExtParam(4));

	-- local tbRate = {};
	-- for i = it.GetExtParam(5), it.GetExtParam(6) do
	-- 	tbRate[i] = Pet.QUALITY_RATE[i];
	-- end
	-- Lib:ShowTB(tbRate);

	--local nQuality = KUnify.MathRandom(it.GetExtParam(5), it.GetExtParam(6));
	
	KItem.DelPlayerItem(me, it);
	print("add pet:", nType, nQuality, nCharacter);
	local pPet = KPet.AddPlayerPet(me, nType, nCharacter);
	
	me.SysMsg(Lang.pet.str51[Lang.Idx] ..pPet.szName);
	
	if nQuality >= 2 then
		local szMsg = string.format(Lang.pet.str52[Lang.Idx],Pet.QUALITY_TIPS[nQuality], pPet.szName);
		me.SendBlackMsg(szMsg);
	end
end

-- ���￨
local tbRideCard = Item:GetClass("ride_card");

function tbRideCard:OnUse()
	local pRide = KPet.GetRide(me);
	--local tbRideColor =
	--{
	--	[1] = "<color=white>",
	--	[2] = "<color=green>",
	--	[3] = "<color=pink>",
	--	[4] = "<color=blue>",
	--	[5] = "<color=purple>",
	--	[6] = "<color=gold>",
	--}
	
	local nGenre = it.nGenre;
	local nDetail = it.nDetail;
	local nParticular = it.nParticular;
	local nLevel = it.nLevel;
	local nHungry = it.GetExtParam(1);
	local nMagicRate = it.GetExtParam(2);
	
	if nHungry == 0 then
		nHungry = Pet.RIDE_MAX_HUNGRY;
	elseif nHungry < 0 then
		nHungry = 0;
	end
	
	KItem.DelPlayerItem(me, it);
	
	-- ��ж�µ�ǰ����
	if pRide then
		local bRet = Pet:TakeOffRide(me, pRide);
		if bRet == 0 then
			return;
		end
	end
	
	local pRide = KPet.AddPlayerRide(me, nGenre, nDetail, nParticular, nLevel, nHungry, nMagicRate);
	me.SysMsg(Lang.pet.str53[Lang.Idx]..pRide.szName);
	--local szMsg = string.format("��װ��������[%s%s<color=white>]", tbRideColor[nLevel], pRide.szName);
	--me.SendBlackMsg(szMsg);
end

local tbTaskPetCard = Item:GetClass("task_pet_card");

function tbTaskPetCard:OnUse()
	local tbPets = KPet.GetPlayerPetList(me);
	local nPetCapacity = me.GetPetCapacity();
	
	if #tbPets == nPetCapacity then
		me.SendBlackMsg(Lang.pet.str54[Lang.Idx]);
		return;
	end
	
	assert(#tbPets < nPetCapacity);
	
	local nType = KUnify.MathRandom(it.GetExtParam(1), it.GetExtParam(2));
	local nCharacter = KUnify.MathRandom(it.GetExtParam(3), it.GetExtParam(4));
	local tbRate = {};
	for i = it.GetExtParam(5), it.GetExtParam(6) do
		tbRate[i] = Pet.QUALITY_RATE[i];
	end
	local nQuality = Lib:RandProb(tbRate);
	assert(nQuality);
	--local nQuality = KUnify.MathRandom(it.GetExtParam(5), it.GetExtParam(6));
	
	KItem.DelPlayerItem(me, it);
	print("add pet:", nType, nQuality, nCharacter);
	local pPet = KPet.AddPlayerPet(me, nType, nCharacter);
	me.SysMsg(Lang.pet.str55[Lang.Idx]..pPet.szName);

	local szMsg = string.format(Lang.pet.str56[Lang.Idx],Pet.QUALITY_TIPS[nQuality], pPet.szName);
	me.SendBlackMsg(szMsg);
end

local tbTaskRideCard = Item:GetClass("task_ride_card");

function tbTaskRideCard:OnUse()
	local pRide = KPet.GetRide(me);
	
	local nGenre = it.GetExtParam(1);
	local nDetail = it.GetExtParam(2);
	local nParticular = it.GetExtParam(3);
	local nLevel = it.GetExtParam(4);
	
	KItem.DelPlayerItem(me, it);
	
	-- ��ж�µ�ǰ����
	if pRide then
		local bRet = Pet:TakeOffRide(me, pRide);
		if bRet == 0 then
			return;
		end
	end
	
	local pRide = KPet.AddPlayerRide(me, nGenre, nDetail, nParticular, nLevel);
	me.SysMsg(Lang.pet.str57[Lang.Idx]..pRide.szName);
end
