
function DailyTasks:c2s_GetAward(pPlayer)
	if pPlayer == nil then 
		return;
	end
	
	local num = Player.tbDegree:GetDegree(pPlayer, "DailyTasks") or 0;
	if num == 1 then
		KAward.AddPlayerAward(pPlayer, "DailyTasks", 1)
		Player.tbDegree:ReduceDegree(pPlayer, "DailyTasks", 1);
	end
end