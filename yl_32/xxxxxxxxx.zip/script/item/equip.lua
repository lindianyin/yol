-- װ�����

function Item:OnEquipOps(nPlayerId)
	local pPlayer = KGameBase.GetPlayerById(nPlayerId);
	if not pPlayer then
		return;
	end
	
	local nGreen = 0;		-- ȫ����װ����
	local nBlue = 0;
	local nPurple = 0;
	local nOrange = 0;
	local nRed = 0;
	local nYellow = 0;
	
	for i = Item.EQUIP_SWORD, Item.EQUIP_FOOT do
		local pEquip = pPlayer.pItem.GetEquipByDetail(i);
		if pEquip then
			if pEquip.nQuality == 2 then
				nGreen = nGreen + 1;
			elseif pEquip.nQuality == 3 then
				nBlue = nBlue + 1;
			elseif pEquip.nQuality == 4 then
				nPurple = nPurple + 1;
			elseif pEquip.nQuality == 5 then
				nOrange = nOrange + 1;
			elseif pEquip.nQuality == 6 then
				nRed = nRed + 1;
			elseif pEquip.nQuality == 7 then
				nYellow = nYellow + 1;
			end
		end
	end
	
	local tNow = KGameBase.GetTime();
	if nGreen == 10 then
		Target:DoTarget(pPlayer, 2);
		if KChat.GetLastBroadcastTime(pPlayer, Chat.BROADCAST_ID_EQUIP_GREEN) == 0 then
			KChat.BroadcastNoticeMsg(string.format(Lang.item.str122[Lang.Idx], pPlayer.szName));
			KChat.ModifyLastBroadcastTime(pPlayer, Chat.BROADCAST_ID_EQUIP_GREEN, tNow);
		end
	elseif nBlue == 10 then
		if KChat.GetLastBroadcastTime(pPlayer, Chat.BROADCAST_ID_EQUIP_BLUE) == 0 then
			KChat.BroadcastNoticeMsg(string.format(Lang.item.str123[Lang.Idx], pPlayer.szName));
			KChat.ModifyLastBroadcastTime(pPlayer, Chat.BROADCAST_ID_EQUIP_BLUE, tNow);
		end
	elseif nPurple == 10 then
		if KChat.GetLastBroadcastTime(pPlayer, Chat.BROADCAST_ID_EQUIP_PURPLE) == 0 then
			KChat.BroadcastNoticeMsg(string.format(Lang.item.str124[Lang.Idx], pPlayer.szName));
			KChat.ModifyLastBroadcastTime(pPlayer, Chat.BROADCAST_ID_EQUIP_PURPLE, tNow);
		end
	elseif nOrange == 10 then
		if KChat.GetLastBroadcastTime(pPlayer, Chat.BROADCAST_ID_EQUIP_ORANGE) == 0 then
			KChat.BroadcastNoticeMsg(string.format(Lang.item.str125[Lang.Idx], pPlayer.szName));
			KChat.ModifyLastBroadcastTime(pPlayer, Chat.BROADCAST_ID_EQUIP_ORANGE, tNow);
		end
	elseif nRed == 10 then
		if KChat.GetLastBroadcastTime(pPlayer, Chat.BROADCAST_ID_EQUIP_RED) == 0 then
			KChat.BroadcastNoticeMsg(string.format(Lang.item.str126[Lang.Idx], pPlayer.szName));
			KChat.ModifyLastBroadcastTime(pPlayer, Chat.BROADCAST_ID_EQUIP_RED, tNow);
		end
	elseif nYellow == 10 then
		if KChat.GetLastBroadcastTime(pPlayer, Chat.BROADCAST_ID_EQUIP_GOLD) == 0 then
			KChat.BroadcastNoticeMsg(string.format(Lang.item.str127[Lang.Idx], pPlayer.szName));
			KChat.ModifyLastBroadcastTime(pPlayer, Chat.BROADCAST_ID_EQUIP_GOLD, tNow);
		end
	end
end

--[[
KChat.BroadcastNoticeMsg(string.format("<%s>����һ����װ����ʱ�о��Լ�ʵ��������", pPlayer.szName));
	elseif nPurple == 10 then
		KChat.BroadcastNoticeMsg(string.format("��װ������<%s>�����Ǽ��߹���ǿ����һ������", pPlayer.szName));
	elseif nOrange == 10 then
		KChat.BroadcastNoticeMsg(string.format("<%s>��һ���ĳ�װ����Ȼ����ɢ����һ��Σ�յ���Ϣ��", pPlayer.szName));
	elseif nRed == 10 then
		KChat.BroadcastNoticeMsg(string.format("<%s>���ϵģ������ǵ�����ѪȾ���ս�ۣ��������ϸ����ĺ�װ��", pPlayer.szName));
	elseif nYellow == 10 then
		KChat.BroadcastNoticeMsg(string.format("��ʲô���������<%s>���ϵľ�Ȼ��һ����װ���ҿ�Ҫ����Ϲ����", pPlayer.szName));
	end--]]


CallCenter:RegisterGlobalEvent(KOBJEVENT.emKOBJEVENTTYPE_PLAYER_EQUIP_OPS, Item.OnEquipOps, Item);