
-- �������

-------------------------------------------------------------------
--File: 	randomitem.lua
--Author: 	
--Date: 	
--Describe:	��ȡ�����Ʒ��ͨ�ýű�
--��һ����չ��������������еĵڼ���
--������չ������ʱ��������

------------------------------------------------------------------------------------------
-- initialize

local tbRandomItem = Item:GetClass("randomitem");

------------------------------------------------------------------------------------------
-- public

local tbRandomFile = Lib:LoadTabFile("/setting/item/magic/randomitem.txt") or {};

function tbRandomItem:OnUse()
	local nNeedBag = 0;
	local nRandomId = tonumber(it.GetExtParam(1));
	for _,tbRow in pairs(tbRandomFile) do  --����-1�����⴦��
		if tonumber(tbRow.KindId) == nRandomId then
			if tonumber(tbRow.Probability) == -1 then
				if (tonumber(tbRow.Genre) and tonumber(tbRow.Genre) ~= 0) then
					nNeedBag = nNeedBag + 1;
				end
			end
		end
	end
	
	for _,tbRow in pairs(tbRandomFile) do  --
		if tonumber(tbRow.KindId) == nRandomId then
			if tonumber(tbRow.Probability) ~= -1 then
				if (tonumber(tbRow.Genre) and tonumber(tbRow.Genre) ~= 0) then
					nNeedBag = nNeedBag + 1;
					return;
				end
			end
		end
	end
	if me.pItem.CountFreeBagCell() < nNeedBag then
		me.SysMsg(Lang.item.str55[Lang.Idx]);
		return 0;
	end
	
	tbRandomItem:SureOnUse();
end

function tbRandomItem:SureOnUse()
	local nRandomId = tonumber(it.GetExtParam(1));
	local nRate = KUnify.MathRandom(1,10000);
	local nId;
	local nLineCount = 0;
	
	for _,tbRow in pairs(tbRandomFile) do  --����-1�����⴦��
		nLineCount = nLineCount + 1;
		if tonumber(tbRow.KindId) == nRandomId then
			if tonumber(tbRow.Probability) == -1 then
				nId = tbRow.Id;
				tbRandomItem:GetItem(nLineCount);
			end
		end
	end
	
	nLineCount = 0;
	for _,tbRow in pairs(tbRandomFile) do  --���������������һ��
		nLineCount = nLineCount + 1;
		if tonumber(tbRow.KindId) == nRandomId then
			if (tonumber(tbRow.Probability) and tonumber(tbRow.Probability) ~= -1) then
				nRate = nRate - tonumber(tbRow.Probability);
				if nRate <= 0 then	--���û�е������ζ����һ�����ʲ����������
					nId = tonumber(tbRow.Id);
					tbRandomItem:GetItem(nLineCount);
					return;
				end
			end
		end	
	end
end

function tbRandomItem:GetItem(nLineCount)
	local nKindId = tonumber(tbRandomFile[nLineCount].KindId);
	local szDesc = tbRandomFile[nLineCount].Desc;
	local nId = tonumber(tbRandomFile[nLineCount].Id);
	local szName = tbRandomFile[nLineCount].Name;
	local nExp = tonumber(tbRandomFile[nLineCount].Exp) or 0;
	local nMoney = tonumber(tbRandomFile[nLineCount].Money) or 0;
	local nYLEnergy = tonumber(tbRandomFile[nLineCount].YLEnergy) or 0;
	local nGenre = tonumber(tbRandomFile[nLineCount].Genre) or 0;
	local nDetailType = tonumber(tbRandomFile[nLineCount].DetailType) or 0;
	local nParticularType = tonumber(tbRandomFile[nLineCount].ParticularType) or 0;
	local nLevel = tonumber(tbRandomFile[nLineCount].Level) or 0;
	local nEnhTimes = tonumber(tbRandomFile[nLineCount].EnhTimes) or 0;
	local nAmount = tonumber(tbRandomFile[nLineCount].Amount) or 1;
	local nBindType = tonumber(tbRandomFile[nLineCount].Bind) or 0;
	local nTimeLimit = tonumber(tbRandomFile[nLineCount].TimeLimit) or 0;
	local nAnnounce = tonumber(tbRandomFile[nLineCount].Announce) or 0;
	local nKinOrTongMsg = tonumber(tbRandomFile[nLineCount].KinOrTongMsg) or 0;
	
	--��ȡ����
	if (nExp and nExp ~= 0 and nAnnounce and nAnnounce ~= 0) then
		me.AddExp(nExp);
		local Msg = string.format(Lang.item.str65[Lang.Idx], me.szName, szName, nExp);
		pPlayer.CallClientScript({"YoulongApp.UI.Controller.QUIClientScript:ShowNoticeMessage", "Msg"});
	elseif (nExp and nExp ~= 0 and nKinOrTongMsg and nKinOrTongMsg ~= 0) then
		me.AddExp(nExp);
		local Msg = string.format(Lang.item.str65[Lang.Idx], me.szName, szName, nExp);
		pPlayer.CallClientScript({"YoulongApp.UI.Controller.QUIClientScript:ShowNoticeMessage", "Msg"});
	elseif (nExp and nExp ~= 0) then
		me.AddExp(nExp);
	end
	
	--��ȡ����
	if (nMoney and nMoney ~= 0 and nAnnounce and nAnnounce ~= 0) then
		me.pPlayerPurse.AddMoney(2, nMoney);
		local Msg = string.format(Lang.item.str66[Lang.Idx], me.szName, szName, nMoney);
		pPlayer.CallClientScript({"YoulongApp.UI.Controller.QUIClientScript:ShowNoticeMessage", "Msg"});
	elseif (nMoney and nMoney ~= 0 and nKinOrTongMsg and nKinOrTongMsg ~= 0) then
		me.pPlayerPurse.AddMoney(2, nMoney);
		local Msg = string.format(Lang.item.str66[Lang.Idx], me.szName, szName, nMoney);
		pPlayer.CallClientScript({"YoulongApp.UI.Controller.QUIClientScript:ShowNoticeMessage", "Msg"});
	elseif (nMoney and nMoney ~= 0) then
		me.pPlayerPurse.AddMoney(2, nMoney);
	end
	
	--��ȡ��������
	if (nYLEnergy and nYLEnergy ~= 0 and nAnnounce and nAnnounce ~= 0) then
		me.pPlayerPurse.AddMoney(6, nYLEnergy);
		local Msg = string.format(Lang.item.str67[Lang.Idx], me.szName, szName, nYLEnergy);
		pPlayer.CallClientScript({"YoulongApp.UI.Controller.QUIClientScript:ShowNoticeMessage", "Msg"});
	elseif (nYLEnergy and nYLEnergy ~= 0 and nKinOrTongMsg and nKinOrTongMsg ~= 0) then
		me.pPlayerPurse.AddMoney(6, nYLEnergy);
		local Msg = string.format(Lang.item.str67[Lang.Idx], me.szName, szName, nYLEnergy);
		pPlayer.CallClientScript({"YoulongApp.UI.Controller.QUIClientScript:ShowNoticeMessage", "Msg"});
	elseif (nYLEnergy and nYLEnergy ~= 0) then
		me.pPlayerPurse.AddMoney(6, nYLEnergy);
	end
	
	--��ȡ����
	if nAmount ~= 0 then  --Amountר���������ӵ���
		local pItem = KItem.AddPlayerItem(me, nGenre, nDetailType, nParticularType, nLevel, nAmount);
		local szItemName = pItem.szName;
		if nBindType and nBindType == 1 then
			pItem.Bind(1);
		end
		if pItem and nAnnounce ~= 0 then
			local Msg = string.format(Lang.item.str68[Lang.Idx], me.szName, szName, nAmount, szItemName);
			pPlayer.CallClientScript({"YoulongApp.UI.Controller.QUIClientScript:ShowNoticeMessage", "Msg"});
		elseif pItem and nKinOrTongMsg ~= 0 then
			local Msg = string.format(Lang.item.str68[Lang.Idx], me.szName, szName, nAmount, szItemName);
			pPlayer.CallClientScript({"YoulongApp.UI.Controller.QUIClientScript:ShowNoticeMessage", "Msg"});
		end
	end
	KItem.DelPlayerItem(me, it);	
	--������ʱ
	--����ǿ������
	--���繫��
	--���幫���

end
