
-- ����״̬
Reward.emAwardStateUnTake = 1;
Reward.emAwardStateHasTaken = 2;
Reward.emAwardStateUnFinish = 3;


-- ����10�����
Reward.MAX_ITEM_AMOUNT = 10;

Reward.emTASK_AWARD_INSTANCE = 1;
Reward.emTASK_AWARD_STAGE = 2;
Reward.emTASK_AWARD_MULTI = 3;