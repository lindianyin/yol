if not MODULE_GAMESERVER then
	return
end

local tbNpc = Npc:GetClass("none")

function tbNpc:OnDialog()

end
