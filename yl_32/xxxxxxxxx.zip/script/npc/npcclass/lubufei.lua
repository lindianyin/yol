
local tbNpc = Npc:GetClass("lubufei")

function tbNpc:OnDialog()
	Dialog:Say(Lang.npc.str78[Lang.Idx]);
end

