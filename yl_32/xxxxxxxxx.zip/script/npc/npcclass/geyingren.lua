
local tbNpc = Npc:GetClass("geyingren")

function tbNpc:OnDialog()
	Dialog:Say(Lang.npc.str77[Lang.Idx]);
end

