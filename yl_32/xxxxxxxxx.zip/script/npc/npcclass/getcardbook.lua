
local tbNpc = Npc:GetClass("getcardbook")

function tbNpc:OnDialog()
	local tbOpt = 
	{
		{Lang.npc.str71[Lang.Idx]},
		{Lang.npc.str72[Lang.Idx],self.GetCardBook, self},
	}
	return Dialog:Say(Lang.npc.str73[Lang.Idx],tbOpt);
end;

function tbNpc:GetCardBook()
	local tbGDPL = { 18, 1, 1 };	-- �û�¼
	
	local tbFind = me.pItem.FindItem(Item.ROOM_MAINBAG, unpack(tbGDPL));
	if (#tbFind >= 1) then
		me.SysMsg(Lang.npc.str74[Lang.Idx]);
		return;
	end
	
	if me.pItem.CountFreeBagCell() < 1 then
		me.SysMsg(Lang.npc.str75[Lang.Idx]);
		return;
	end
	
	KItem.AddPlayerItem(me, unpack(tbGDPL));
	me.SysMsg(Lang.npc.str76[Lang.Idx]);
end


--[[
function tbNpc:OnDialog()
	local tbOpt = 
	{
		{"��ȡ�ʺ�װ��",self.GetEquip,self},
		{"��Ҫ�뿪pk��",self.LeaveMap,self},
		{"ȡ��"},
	}
	return Dialog:Say("����Ҫ��ʲô",tbOpt);
end;

function tbNpc:LeaveMap()
	me.SetLevel(me.pTask.GetTask(2052,1) or me.GetLevel());
	me.TeleportTo(100,1904,7121,1048576);
	me.SetCurrentCamp(1);
end
--]]
