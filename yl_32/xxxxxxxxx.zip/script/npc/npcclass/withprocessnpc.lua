
local tbNpc = Npc:GetClass("withprocessnpc")

function tbNpc:OnDialog()
	Task:OnExclusiveDialogNpc();
end;
