if (not MODULE_GAMESERVER and not MODULE_GAMECLIENT) then
	return;
end
local self;

