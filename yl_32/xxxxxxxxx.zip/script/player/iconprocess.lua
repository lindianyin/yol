
function Player:c2s_TaskIconProcess(pPlayer)
	Task:OnExclusiveIconProcess(pPlayer);
end