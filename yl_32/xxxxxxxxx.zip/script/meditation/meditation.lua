
Meditation.OfflineAwardType = {1,2,3,6};	-- ���ߴ����콱����
Meditation.OfflineAwardCost = {0,5,10,20}; --���ߴ�����ȡ����
Meditation.TotalTime = 12 * 60 * 60; -- ÿ��������ʱ������
Meditation.ExpPercent = 0.2;		 -- ������ÿ��õ�ǰ�ȼ���������ٷֱ�(�����ñ��в�����ĳһ�ȼ�ʱ)
Meditation.BaseTime = 30;			 -- ÿ30s��һ�ν���
Meditation.RequireLevel = 22;		 -- �������ŵȼ�
Meditation.SilverAward = {100, 200, 300, 400, 500, 600, 700, 800, 900, 1000};		 -- ��������ÿ30���õ���������
Meditation.BonfireAddPercent = {1, 1.1, 1.2, 1.3, 1.4 , 1.5, 1.6, 1.7, 1.8, 1.9, 2.0};	--����ӳɾ���
Meditation.OfflineRemindIdx = 29;	--���߾�������
Meditation.tbAwardCfg = {};

function Meditation:Init()
	self.nTotalExp = {};	--�ۼƾ���ͳ��
	self.nTotalSilver = {};	--�ۼ�����ͳ��
	self.tbPlayerOfflineExp = {}; -- ���߾���
	self:LoadMeditation();	--load����
end

function Meditation:SetMeditationTotalTime(nTime)
	Meditation.TotalTime = nTime;
end

function Meditation:OpenOfflineMeditationPanel(pPlayer)
	local dwNow = KGameBase.GetTime();
	local dwTakeOfflineAwardTime = pPlayer.GetTakeMeditationOfflineAwardTime();

	local nLastMeditationOnlineTime = pPlayer.GetLastMeditationOnlineTime();
	if nLastMeditationOnlineTime >= Meditation.TotalTime then
		nLastMeditationOnlineTime = Meditation.TotalTime;
	end
	
	local nLevel = pPlayer.GetLevel();
	local dwExpPercent = Meditation.ExpPercent;
	if Meditation.tbAwardCfg[nLevel] ~= nil then
		dwExpPercent = Meditation.tbAwardCfg[nLevel].nExpPercent / 100.0;
	end
	
	if self.tbPlayerOfflineExp[pPlayer.dwId] == nil then
		if Lib:GetLocalDay(dwNow) ~= Lib:GetLocalDay(dwTakeOfflineAwardTime) then
			local totalExp = KGameBase.GetNextLevelExp(nLevel) * dwExpPercent;
			local nTimeSeconds = Meditation.TotalTime - nLastMeditationOnlineTime;
			local OfflineExp = math.floor( totalExp * 0.5 *  nTimeSeconds / Meditation.TotalTime);
			print(Lang.meditation.str1[Lang.Idx], nTimeSeconds, OfflineExp);
			self.tbPlayerOfflineExp[pPlayer.dwId] = {OfflineExp, nTimeSeconds}
			pPlayer.CallClientScript({"YoulongApp.UI.Controller.QUIClientScript:SetMeditationOfflinePanelContent", nTimeSeconds, OfflineExp});
			Remind:AddRemindToPlayer(pPlayer, Meditation.OfflineRemindIdx, -1);
		end
	else
	   local offlineExp  = self.tbPlayerOfflineExp[pPlayer.dwId][1]
	   local offlineTime = self.tbPlayerOfflineExp[pPlayer.dwId][2]
	   print(Lang.meditation.str2[Lang.Idx], offlineTime, offlineExp);
	   pPlayer.CallClientScript({"YoulongApp.UI.Controller.QUIClientScript:SetMeditationOfflinePanelContent", offlineTime, offlineExp});
		 Remind:AddRemindToPlayer(pPlayer, Meditation.OfflineRemindIdx, -1);
	end
end

function Meditation:ErrorMsg(pPlayer, strMsg)
	if pPlayer then
		pPlayer.SendBlackMsg(strMsg);
	end
end

function Meditation:OnLogin(nPlayerId)
	local pPlayer = KGameBase.GetPlayerById(nPlayerId);
	if not pPlayer then
		return;
	end
	
	if pPlayer.GetLevel() < Meditation.RequireLevel then
		return;
	end
	
	local dwNow = KGameBase.GetTime();
	local dwLastLogoutTime = pPlayer.GetLastLogoutTime();
	
	if Lib:GetLocalDay(dwNow) ~= Lib:GetLocalDay(dwLastLogoutTime) then
		pPlayer.ResetMeditationData();
	end	
	Meditation:OpenOfflineMeditationPanel(pPlayer);
end

function Meditation:ResetMeditationData()
	local tbPlayers = KGameBase.GetAllPlayers()
	for _, pPlayer in pairs(tbPlayers) do
		if pPlayer.GetLevel() >= Meditation.RequireLevel then
			pPlayer.ResetMeditationData();
			local nLastMeditationOnlineTime = pPlayer.GetLastMeditationOnlineTime();
			if nLastMeditationOnlineTime >= Meditation.TotalTime then
				nLastMeditationOnlineTime = Meditation.TotalTime;
			end
			
			local nLevel = pPlayer.GetLevel();
			local dwExpPercent = Meditation.ExpPercent;
			if Meditation.tbAwardCfg[nLevel] ~= nil then
				dwExpPercent = Meditation.tbAwardCfg[nLevel].nExpPercent / 100.0;
			end
	
			local totalExp = KGameBase.GetNextLevelExp(nLevel) * dwExpPercent;
			local nTimeSeconds = Meditation.TotalTime - nLastMeditationOnlineTime;
			local OfflineExp = math.floor( totalExp * 0.5 *  nTimeSeconds / Meditation.TotalTime);
			print(Lang.meditation.str1[Lang.Idx], nTimeSeconds, OfflineExp);
			self.tbPlayerOfflineExp[pPlayer.dwId] = {OfflineExp, nTimeSeconds}
			pPlayer.CallClientScript({"YoulongApp.UI.Controller.QUIClientScript:SetMeditationOfflinePanelContent", nTimeSeconds, OfflineExp});
			Remind:AddRemindToPlayer(pPlayer, Meditation.OfflineRemindIdx, -1);
		end
	end
end

function Meditation:c2s_TakeOfflineAward(pPlayer, nType)
	if not Meditation.OfflineAwardType[nType] then
		return;
	end
	if pPlayer.GetLevel() < Meditation.RequireLevel then
		return;
	end
	
	local vipId = 0;
	if nType == 2 then
		vipId = Vip.ID_MEDITATION_OFFLINE_2;
	elseif nType == 3 then
		vipId = Vip.ID_MEDITATION_OFFLINE_3;
	elseif nType == 4 then
		vipId = Vip.ID_MEDITATION_OFFLINE_6;
	end
	
	if vipId~= 0 and Vip:IsOpen(pPlayer, vipId) ~= 1 then
		--pPlayer.SendBlackMsg("��ǰvip�ȼ�δ�����˹��ܣ�������vip!");
		return;
	end
	
	if pPlayer.pPlayerPurse.GetMoney(Purse.EM_MONEY_COIN) < Meditation.OfflineAwardCost[nType] then
		pPlayer.SendBlackMsg(string.format(Lang.meditation.str3[Lang.Idx], Meditation.OfflineAwardCost[nType]));
		return;
	end
	
	pPlayer.pPlayerPurse.AddMoney(Purse.EM_MONEY_COIN, -Meditation.OfflineAwardCost[nType]);
	local nLastMeditationOnlineTime = pPlayer.GetLastMeditationOnlineTime();
	if nLastMeditationOnlineTime >= Meditation.TotalTime then
		nLastMeditationOnlineTime = Meditation.TotalTime;
	end
	
	--[[local nLevel = pPlayer.GetLevel();
	local dwExpPercent = Meditation.ExpPercent;
	if Meditation.tbAwardCfg[nLevel] ~= nil then
		dwExpPercent = Meditation.tbAwardCfg[nLevel].nExpPercent / 100.0;
	end
	
	local totalExp = KGameBase.GetNextLevelExp(nLevel) * dwExpPercent;
	local OfflineExp = math.floor( totalExp * 0.5 * (Meditation.TotalTime - nLastMeditationOnlineTime) / Meditation.TotalTime) * Meditation.OfflineAwardType[nType];--]]
	 
	local offlineExp  = self.tbPlayerOfflineExp[pPlayer.dwId][1] * Meditation.OfflineAwardType[nType]
	--local offlineTime = self.tbPlayerOfflineExp[pPlayer.dwId][2]
	pPlayer.SetTakeMeditationOfflineAwardTime(KGameBase.GetTime());
	pPlayer.AddExp(offlineExp);

	pPlayer.CallClientScript({"YoulongApp.UI.Controller.QUIClientScript:HideMeditationOfflinePanel"});
	Remind:RemoveRemindToPlayer(pPlayer, Meditation.OfflineRemindIdx);
	self.tbPlayerOfflineExp[pPlayer.dwId] = nil
end

--C++��ÿ30s��һ�ν���
function Meditation:GiveOnlineAward(pPlayer)
	if pPlayer.GetLevel() < Meditation.RequireLevel then
		return;
	end
	
	--�ж��Ƿ���������
	local bonfire = Activity:GetBonfireStatus(pPlayer);
	local bonfireAddExp = 0;
	local bonfireAddSilver = 0;
	local bonfireLeftTime = 0;
	
	local dwMeditationOnlineTime = pPlayer.GetMeditationOnlineTime();
	local tbPlayerKinInfo = GetPlayerKinInfo(pPlayer.dwId);
	--print("���ߴ���ʱ��:",dwMeditationOnlineTime);
	if dwMeditationOnlineTime > Meditation.TotalTime then
		dwMeditationOnlineTime = Meditation.TotalTime;
	else
		local nNum = Meditation.TotalTime / Meditation.BaseTime;
		local nLevel = pPlayer.GetLevel();
		local dwExpPercent = Meditation.ExpPercent;
		if Meditation.tbAwardCfg[nLevel] ~= nil then
			dwExpPercent = Meditation.tbAwardCfg[nLevel].nExpPercent / 100.0;
		end
	
		local totalExp = KGameBase.GetNextLevelExp(nLevel) * dwExpPercent;
		local addExp = math.floor(totalExp / nNum);
		if bonfire == 1 then
			if tbPlayerKinInfo ~= nil and tbPlayerKinInfo.nKinLevel > 0 then
				bonfireAddExp = addExp * Meditation.BonfireAddPercent[tbPlayerKinInfo.nKinLevel];
				bonfireAddSilver = Meditation.SilverAward[tbPlayerKinInfo.nKinLevel];
				bonfireLeftTime = Activity:GetKinActivityLeftTime(pPlayer.GetKinId(), 1001);
				pPlayer.pPlayerPurse.AddMoney(Purse.EM_MONEY_SILVER, bonfireAddSilver);
			end
		end
		
		if not self.nTotalExp[pPlayer.dwId] then
			self.nTotalExp[pPlayer.dwId] = 0;
		end
		
		self.nTotalExp[pPlayer.dwId] = self.nTotalExp[pPlayer.dwId] + addExp + bonfireAddExp;
		pPlayer.AddExp(addExp + bonfireAddExp);
	end
	local nTimeSeconds = Meditation.TotalTime - dwMeditationOnlineTime;

	local bonfireExp = 0;
	if tbPlayerKinInfo ~= nil and tbPlayerKinInfo.nKinLevel > 0 then
		bonfireExp = self.nTotalExp[pPlayer.dwId] / (1 + Meditation.BonfireAddPercent[tbPlayerKinInfo.nKinLevel]) * Meditation.BonfireAddPercent[tbPlayerKinInfo.nKinLevel];
	end
	
	if not self.nTotalSilver[pPlayer.dwId] then
		self.nTotalSilver[pPlayer.dwId] = 0;
	end
	self.nTotalSilver[pPlayer.dwId] = self.nTotalSilver[pPlayer.dwId] + bonfireAddSilver;
	Pet:GetDownRide(pPlayer);
	pPlayer.CallClientScript({"YoulongApp.UI.Controller.QUIClientScript:SetMeditationOnlinePanelContent", nTimeSeconds, self.nTotalExp[pPlayer.dwId], bonfire, math.floor(bonfireExp), self.nTotalSilver[pPlayer.dwId], bonfireLeftTime});
	
end

function Meditation:ResetOnlineTotalExp(pPlayer)
	self.nTotalExp[pPlayer.dwId] = 0;
	self.nTotalSilver[pPlayer.dwId] = 0;
end

function Meditation:ShowMeditationOnlinePanel(pPlayer)
	if pPlayer.GetLevel() < Meditation.RequireLevel then
		return;
	end
	local dwMeditationOnlineTime = pPlayer.GetMeditationOnlineTime();
	if dwMeditationOnlineTime > Meditation.TotalTime then
		dwMeditationOnlineTime = Meditation.TotalTime;
	end
	if not self.nTotalExp[pPlayer.dwId] then
		self.nTotalExp[pPlayer.dwId] = 0;
	end
	local nTimeSeconds = Meditation.TotalTime - dwMeditationOnlineTime;
	
	local bonfire = Activity:GetBonfireStatus(pPlayer);
	local bonfireLeftTime = 0;
	if bonfire == 1 then
		bonfireLeftTime = Activity:GetKinActivityLeftTime(pPlayer.GetKinId(), 1001);
	end
	if not self.nTotalSilver[pPlayer.dwId] then
		self.nTotalSilver[pPlayer.dwId] = 0;
	end
	Pet:GetDownRide(pPlayer);
	pPlayer.CallClientScript({"YoulongApp.UI.Controller.QUIClientScript:SetMeditationOnlinePanelContent",nTimeSeconds, self.nTotalExp[pPlayer.dwId], bonfire, 0, 0, bonfireLeftTime});
end

function Meditation:HideMeditationOnlinePanel(pPlayer)
	if pPlayer then
		pPlayer.CallClientScript({"YoulongApp.UI.Controller.QUIClientScript:HideMeditationOnlinePanel"});
	end
end

function Meditation:OnEnterScene(dwCharacterId)
	local pPlayer = KGameBase.GetCharacterById(dwCharacterId);
	
	if pPlayer.IsNpc() == 1 then
		return;
	end
	
	if pPlayer.GetIsFightMap() > 0 then 
		--�ر����ߴ������
		Meditation:HideMeditationOnlinePanel(pPlayer);
		pPlayer.SetMeditationState(0);
	end
end

function Meditation:LoadMeditation()
	local cfgs = Meditation.tbAwardCfg;
	local tbFileData = Lib:LoadTabFile("/setting/meditation/meditation_award.txt");
	for _, tbRow in pairs(tbFileData) do
		local nLevel = tonumber(tbRow.Level);
		assert(nLevel);
		if not cfgs[nLevel] then
			cfgs[nLevel] = {
			nExpPercent = tonumber(tbRow.ExpPercent);
			};
		end
	end
end

Meditation:Init();

CallCenter:RegisterGlobalEvent(KOBJEVENT.emKOBJEVENTTYPE_PLAYER_LOGIN, Meditation.OnLogin, Meditation);
CallCenter:RegisterGlobalEvent(KOBJEVENT.emKOBJEVENTTYPE_CHARACTER_ENTER_SCENE, Meditation.OnEnterScene, Meditation);