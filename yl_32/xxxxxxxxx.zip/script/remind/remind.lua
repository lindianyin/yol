
Remind.ID_LIAN_GUA 				= 1;		--炼卦
Remind.ID_EMAIL 				= 2;		--邮件
--[[Remind.ID_LIAN_GUA 				= 3;		--家族申请
Remind.ID_LIAN_GUA 				= 4;		--组队申请
Remind.ID_LIAN_GUA 				= 5;		--通用领奖
Remind.ID_LIAN_GUA 				= 6;		--修炼打坐
Remind.ID_LIAN_GUA 				= 7;		--家族篝火
Remind.ID_LIAN_GUA 				= 8;		--泡澡开始前5分钟
Remind.ID_LIAN_GUA 				= 9;		--泡澡进行中
Remind.ID_LIAN_GUA 				= 10;		--泡澡结束前5分钟
Remind.ID_LIAN_GUA 				= 11;		--战神无双开始前5分钟
Remind.ID_LIAN_GUA 				= 12;		--战神无双进行中
Remind.ID_LIAN_GUA 				= 13;		--战神无双结束前5分钟--]]
Remind.ID_QUIZ_START 			= 14;		--答题开始前5分钟
Remind.ID_QUIZ_GOING 			= 15;		--答题进行中
Remind.ID_QUIZ_END 				= 16;		--答题结束前5分钟
--[[Remind.ID_LIAN_GUA 				= 17;		--世界boss开始前5分钟
Remind.ID_LIAN_GUA 				= 18;		--世界boss进行中
Remind.ID_LIAN_GUA 				= 19;		--世界boss结束前5分钟
Remind.ID_LIAN_GUA 				= 20;		--战宝堂开始前5分钟
Remind.ID_LIAN_GUA 				= 21;		--战宝堂进行中
Remind.ID_LIAN_GUA 				= 22;		--战宝堂结束前5分钟
Remind.ID_LIAN_GUA 				= 23;		--战场开始前5分钟
Remind.ID_LIAN_GUA 				= 24;		--战场进行中
Remind.ID_LIAN_GUA 				= 25;		--战场结束前5分钟
Remind.ID_LIAN_GUA 				= 26;		--家族战开始前5分钟
Remind.ID_LIAN_GUA 				= 27;		--家族战进行中
Remind.ID_LIAN_GUA 				= 28;		--家族战结束前5分钟
Remind.ID_LIAN_GUA 				= 29;		--家族城战开始前5分钟
Remind.ID_LIAN_GUA 				= 30;		--家族城战进行中
Remind.ID_LIAN_GUA 				= 31;		--家族城战结束前5分钟--]]

Remind.ID_KINBATTLE_START		= 32;
Remind.ID_KINBATTLE_GOING		= 33;
Remind.ID_KINBATTLE_END			= 34;


function Remind:AddRemindToPlayer(pPlayer, nRemindId, nCountDown)
	if pPlayer == nil then
		return
	end 
	KRemind.AddRemindToPlayer(pPlayer, nRemindId, nCountDown);
end

function Remind:RemoveRemindToPlayer(pPlayer, nRemindId)
	if pPlayer == nil then
		return
	end 
	KRemind.RemoveRemindToPlayer(pPlayer, nRemindId);
end

function Remind:RemindToAllPlayers(nRemindId, nCountDown)
	local tbPlayers = KGameBase.GetAllPlayers()
	for _, pPlayer in pairs(tbPlayers) do
		KRemind.AddRemindToPlayer(pPlayer, nRemindId, nCountDown);
	end
end

function Remind:c2s_AddRemindToPlayer(pPlayer, nRemindId, nCountDown, playerId)
	if playerId ~= nil and playerId > 0 then
		Remind:AddRemindToPlayer(KGameBase.GetPlayerById(nId), nRemindId, nCountDown);
	else
		Remind:AddRemindToPlayer(pPlayer, nRemindId, nCountDown);
	end
end

function Remind:c2s_RemoveRemindToPlayer(pPlayer, nRemindId, playerId)
	if playerId > 0 then
		Remind:RemoveRemindToPlayer(KGameBase.GetPlayerById(nId), nRemindId);
	else
		Remind:RemoveRemindToPlayer(pPlayer, nRemindId);
	end
end