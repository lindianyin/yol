﻿btnName：拿图片的按钮名字
startTime：开服后XXX天开始
endTime：开服后XXX天结束
targetPath:本文件夹的内容表
regionId：内容表对应的ID
awardModuleName:奖励表模块名字

通用时长活动的内容，ID区间为30，每一批都得按照这个区间去填
